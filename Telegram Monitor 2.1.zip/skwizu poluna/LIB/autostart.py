# -*- coding: utf-8 -*-
"""
Telegram Monitor 2.1 - автозапуск при входе в Windows.

Используется ветка реестра текущего пользователя:
  HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\Run
Права администратора не нужны. Два режима:

  console    - открывается окно START.bat с рамкой (как раньше);
  background - запуск без окна через pythonw, остаётся только значок
               в трее (нужны pystray и Pillow, сессия Telegram должна
               быть уже авторизована).
"""

import os
import sys

try:
    import winreg
except ImportError:  # не Windows
    winreg = None

LIB_DIR = os.path.dirname(os.path.abspath(__file__))
BASE_DIR = os.path.dirname(LIB_DIR)
START_BAT = os.path.join(BASE_DIR, "START.bat")
START_BACKGROUND_BAT = os.path.join(BASE_DIR, "START_BACKGROUND.bat")
MAIN_PY = os.path.join(LIB_DIR, "main.py")

RUN_KEY = r"Software\Microsoft\Windows\CurrentVersion\Run"
VALUE_NAME = "TelegramMonitor"


def is_supported():
    return winreg is not None and os.path.isfile(START_BAT)


def _pythonw():
    candidate = os.path.join(os.path.dirname(sys.executable), "pythonw.exe")
    return candidate if os.path.isfile(candidate) else None


def _command(background):
    # Кавычки вокруг путей обязательны: в пути могут быть пробелы и кириллица.
    if background:
        pythonw = _pythonw()
        if pythonw:
            return '"%s" "%s" run --background' % (pythonw, MAIN_PY)
        return 'cmd.exe /c ""%s""' % START_BACKGROUND_BAT
    return 'cmd.exe /c ""%s""' % START_BAT


def _read_value():
    if winreg is None:
        return ""
    try:
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, RUN_KEY, 0, winreg.KEY_READ) as key:
            value, _ = winreg.QueryValueEx(key, VALUE_NAME)
            return str(value or "")
    except OSError:
        return ""


def is_enabled():
    return bool(_read_value())


def current_mode():
    """None, 'console' или 'background'."""
    value = _read_value()
    if not value:
        return None
    if "--background" in value or "START_BACKGROUND" in value:
        return "background"
    return "console"


def enable(background=False):
    """Включает автозапуск. Возвращает (успех, сообщение)."""
    if winreg is None:
        return False, "Автозапуск поддерживается только в Windows."
    required = START_BACKGROUND_BAT if background else START_BAT
    if not os.path.isfile(required):
        return False, "Не найден файл %s" % required
    try:
        with winreg.CreateKeyEx(
            winreg.HKEY_CURRENT_USER, RUN_KEY, 0, winreg.KEY_SET_VALUE
        ) as key:
            winreg.SetValueEx(key, VALUE_NAME, 0, winreg.REG_SZ, _command(background))
        if background:
            return True, (
                "Автозапуск включён (фон, без окна). При входе в Windows программа "
                "запустится в трее."
            )
        return True, (
            "Автозапуск включён. При следующем входе в Windows откроется "
            "окно START.bat с мониторингом."
        )
    except OSError as exc:
        return False, "Не удалось включить автозапуск: %s" % exc


def disable():
    """Отключает автозапуск. Возвращает (успех, сообщение)."""
    if winreg is None:
        return False, "Автозапуск поддерживается только в Windows."
    try:
        with winreg.OpenKey(
            winreg.HKEY_CURRENT_USER, RUN_KEY, 0, winreg.KEY_SET_VALUE
        ) as key:
            winreg.DeleteValue(key, VALUE_NAME)
        return True, "Автозапуск отключён."
    except FileNotFoundError:
        return True, "Автозапуск уже был отключён."
    except OSError as exc:
        return False, "Не удалось отключить автозапуск: %s" % exc


def status_text():
    if winreg is None:
        return "недоступен (не Windows)"
    mode = current_mode()
    if mode == "background":
        return "ВКЛЮЧЁН (фон, трей)"
    if mode == "console":
        return "ВКЛЮЧЁН (окно CMD)"
    return "выключен"
