# -*- coding: utf-8 -*-
"""
Telegram Monitor 2.1 - работа с Telegram через Telethon (официальный MTProto API).

Запрашиваются только те сведения, которые Telegram разрешает видеть
вашему аккаунту. Настройки приватности цели не обходятся.

ВАЖНО: строка "from telethon import sync" включает синхронный режим Telethon.
Без неё методы клиента возвращают корутины, а не результат, и появляется
предупреждение "coroutine 'TelegramBaseClient.connect' was never awaited":
соединение при этом не устанавливается вообще.
"""

import inspect

from telethon import TelegramClient
from telethon import sync  # noqa: F401  (включает синхронный режим)
from telethon.errors import (
    AuthKeyUnregisteredError,
    FloodWaitError,
    PasswordHashInvalidError,
    PhoneCodeExpiredError,
    PhoneCodeInvalidError,
    PhoneNumberInvalidError,
    SessionPasswordNeededError,
    UnauthorizedError,
)
from telethon.tl.functions.users import GetFullUserRequest
from telethon.tl.types import (
    User,
    UserStatusEmpty,
    UserStatusLastMonth,
    UserStatusLastWeek,
    UserStatusOffline,
    UserStatusOnline,
    UserStatusRecently,
)

from config import SESSION_NAME

# Признаки профиля, которые показываются в рамке CMD, если Telegram их отдаёт.
_BADGES = (
    ("verified", "VERIFIED"),
    ("premium", "PREMIUM"),
    ("bot", "BOT"),
    ("scam", "SCAM"),
    ("fake", "FAKE"),
    ("restricted", "RESTRICTED"),
    ("contact", "CONTACT"),
    ("mutual_contact", "MUTUAL"),
    ("deleted", "DELETED"),
)


class TargetNotFound(Exception):
    """Пользователь не найден или недоступен по указанному username/ID."""


class SessionInvalid(Exception):
    """Сессия Telegram отозвана или недействительна."""


class TelegramMonitorClient(object):
    def __init__(self, settings):
        self.settings = settings
        self.phone = str(settings.get("phone") or "").strip()
        self.me_username = ""
        self.client = TelegramClient(
            SESSION_NAME,
            int(settings.get("api_id") or 0),
            str(settings.get("api_hash") or ""),
        )

    # --------------------------------------------------------------- служебное
    def _run(self, value):
        """
        Если вызов вернул корутину (синхронный режим не включился по какой-то
        причине), выполняет её в цикле Telethon. Иначе возвращает результат как есть.
        """
        if inspect.isawaitable(value):
            return self.client.loop.run_until_complete(value)
        return value

    # ------------------------------------------------------------ соединение
    def connect_once(self):
        """Одна попытка подключения. Возвращает (успех, текст_ошибки)."""
        try:
            self._run(self.client.connect())
            if self.client.is_connected():
                return True, ""
            return False, "not connected"
        except Exception as exc:  # noqa: BLE001 - сеть бывает любой
            return False, str(exc) or exc.__class__.__name__

    def is_authorized(self):
        try:
            return bool(self._run(self.client.is_user_authorized()))
        except Exception:  # noqa: BLE001
            return False

    def reconnect(self):
        """Быстрая попытка восстановить соединение без длинных пауз."""
        try:
            if not self.client.is_connected():
                self._run(self.client.connect())
            return bool(self.client.is_connected())
        except Exception:  # noqa: BLE001
            return False

    def load_me(self):
        """Запоминает username собственного аккаунта (для рамки в CMD)."""
        try:
            me = self._run(self.client.get_me())
            self.me_username = (getattr(me, "username", None) or "") if me else ""
        except Exception:  # noqa: BLE001
            self.me_username = ""
        return self.me_username

    def sign_in_interactive(self, log=print):
        """
        Вход в аккаунт: код из Telegram и, при необходимости, пароль 2FA.
        Код вводится в том же окне CMD.
        """
        if self.is_authorized():
            return True

        try:
            self._run(self.client.send_code_request(self.phone))
        except PhoneNumberInvalidError:
            log("Telegram reports the phone number as invalid.")
            return False
        except FloodWaitError as exc:
            log("Telegram limited code requests. Wait %d sec." % int(exc.seconds))
            return False
        except Exception as exc:  # noqa: BLE001
            log("Could not request the confirmation code: %s" % exc)
            return False

        for attempt in range(1, 4):
            try:
                code = input("Enter the confirmation code from Telegram: ").strip()
            except EOFError:
                return False
            if not code:
                return False
            try:
                self._run(self.client.sign_in(phone=self.phone, code=code))
                return True
            except SessionPasswordNeededError:
                try:
                    password = input("Enter the two-step verification password: ")
                except EOFError:
                    return False
                if not password:
                    return False
                try:
                    self._run(self.client.sign_in(password=password))
                    return True
                except PasswordHashInvalidError:
                    log("Wrong two-step verification password.")
                    return False
                except FloodWaitError as exc:
                    log("Telegram limited sign-in attempts. Wait %d sec." % int(exc.seconds))
                    return False
                except Exception as exc:  # noqa: BLE001
                    log("Sign-in error: %s" % exc)
                    return False
            except (PhoneCodeInvalidError, PhoneCodeExpiredError):
                log("The code is invalid or expired (attempt %d of 3)." % attempt)
            except FloodWaitError as exc:
                log("Telegram limited sign-in attempts. Wait %d sec." % int(exc.seconds))
                return False
            except Exception as exc:  # noqa: BLE001
                log("Sign-in error: %s" % exc)
                return False
        return False

    def disconnect(self):
        try:
            self._run(self.client.disconnect())
        except Exception:  # noqa: BLE001
            pass

    # ----------------------------------------------------------------- данные
    @staticmethod
    def _target_query(target):
        """
        Приводит цель к виду, понятному Telethon:
        числовой ID -> int, username/телефон -> строка.
        """
        target = str(target or "").strip()
        if target.isdigit():
            return int(target)
        return target

    def _resolve_entity(self, target, known_id):
        """
        Ищет пользователя: сначала по сохранённому user_id (стабильный
        идентификатор), затем по username/ID из настроек. Так смена username
        не приводит к потере цели, если сессия Telegram её помнит.
        """
        candidates = []
        if known_id:
            try:
                candidates.append(int(known_id))
            except (TypeError, ValueError):
                pass
        query = self._target_query(target)
        if query not in candidates:
            candidates.append(query)

        last_error = None
        for candidate in candidates:
            try:
                entity = self._run(self.client.get_entity(candidate))
            except (AuthKeyUnregisteredError, UnauthorizedError, FloodWaitError):
                raise
            except Exception as exc:  # noqa: BLE001 - пробуем следующий вариант
                last_error = exc
                continue
            if isinstance(entity, User):
                return entity
            last_error = ValueError(
                "target is not a user (channels, groups and bots are not supported)"
            )
        raise TargetNotFound(str(last_error) if last_error else "user not found")

    def get_snapshot(self, target, known_id=None):
        """
        Возвращает (snapshot, retry_after, reason):
          snapshot    - dict с данными профиля/статуса либо None;
          retry_after - сколько секунд подождать перед повтором;
          reason      - 'flood' | 'network' | None.

        Исключения:
          TargetNotFound - пользователь не найден;
          SessionInvalid - сессия отозвана.
        """
        try:
            user = self._resolve_entity(target, known_id)
            result = self._run(self.client(GetFullUserRequest(user)))
        except TargetNotFound:
            raise
        except FloodWaitError as exc:
            return None, int(exc.seconds) + 2, "flood"
        except (AuthKeyUnregisteredError, UnauthorizedError) as exc:
            raise SessionInvalid(str(exc))
        except (OSError, ConnectionError, TimeoutError, RuntimeError):
            return None, 15, "network"
        except Exception:  # noqa: BLE001
            # Неизвестная ошибка API: не роняем программу, ждём и повторяем.
            return None, 30, "network"

        # Telethon возвращает UserFull напрямую. На случай обёртки-контейнера
        # (full_user/users) поддерживаем оба варианта.
        full_user = result
        if getattr(result, "users", None):
            for candidate in result.users:
                if getattr(candidate, "id", None) == user.id:
                    user = candidate
                    break
        nested_full_user = getattr(result, "full_user", None)
        if nested_full_user is not None:
            full_user = nested_full_user

        status, status_label, was_online = self._read_status(user, full_user)

        # В UserFull лежит более свежая фотография, чем в объекте User.
        photo = getattr(user, "photo", None)
        if full_user is not None and hasattr(full_user, "profile_photo"):
            photo = full_user.profile_photo
        photo_id = getattr(photo, "photo_id", None) if photo is not None else None
        if not photo_id:
            photo_id = None

        bio = getattr(full_user, "about", None) if full_user is not None else None
        if bio is not None:
            bio = str(bio).strip() or None

        badges = [
            name for attr, name in _BADGES if getattr(user, attr, False) is True
        ]
        phone = getattr(user, "phone", None)

        snapshot = {
            "_user": user,
            "user_id": user.id,
            "first_name": user.first_name,
            "last_name": user.last_name,
            "username": user.username,
            "photo_id": str(photo_id) if photo_id is not None else None,
            "bio": bio,
            "status": status,
            "status_label": status_label,
            "was_online": was_online,
            "phone": ("+" + str(phone).lstrip("+")) if phone else None,
            "badges": badges,
        }
        return snapshot, None, None

    @staticmethod
    def _read_status(user, full_user):
        """
        Возвращает (status, label, was_online_datetime|None).

        status:
          'online'      - точно в сети;
          'offline'     - точно не в сети, известно точное время визита;
          'hidden'      - Telegram показывает только приблизительное
                          "недавно / на этой неделе / в прошлом месяце";
          'unavailable' - статус не отдаётся вовсе.

        Приблизительные значения НЕ выдаются за точное время.
        """
        status = getattr(full_user, "status", None) if full_user else None
        if status is None:
            status = getattr(user, "status", None)

        if isinstance(status, UserStatusOnline):
            return "online", "ONLINE", None
        if isinstance(status, UserStatusOffline):
            was_online = status.was_online
            if was_online is not None and was_online.tzinfo is not None:
                was_online = was_online.astimezone().replace(tzinfo=None)
            if was_online is not None:
                # Секундная точность: так же время хранится в базе.
                was_online = was_online.replace(microsecond=0)
            return "offline", "OFFLINE", was_online
        if isinstance(status, UserStatusRecently):
            return "hidden", "RECENTLY", None
        if isinstance(status, UserStatusLastWeek):
            return "hidden", "LAST WEEK", None
        if isinstance(status, UserStatusLastMonth):
            return "hidden", "LAST MONTH", None
        if isinstance(status, UserStatusEmpty):
            return "unavailable", "UNAVAILABLE", None
        return "unavailable", "UNAVAILABLE", None

    def download_avatar(self, snap, path):
        """Скачивает текущую аватарку цели в указанный файл."""
        user = snap.get("_user")
        if user is None:
            return None
        return self._run(self.client.download_profile_photo(user, file=path))

    def describe_target(self, snap):
        name = " ".join(
            part for part in (snap.get("first_name"), snap.get("last_name")) if part
        ).strip()
        username = snap.get("username")
        if username:
            return "%s (@%s)" % (name or "no name", username)
        return name or "no name"
