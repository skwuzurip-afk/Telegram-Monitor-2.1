# -*- coding: utf-8 -*-
"""
Telegram Monitor 2.1 - значок в трее (pystray + Pillow).

Меню: веб-панель, показать/скрыть консоль, пауза, проверка обновлений,
папка программы, выход. Цвет значка отражает состояние: зелёный - цель
в сети, серый - не в сети, жёлтый - пауза/скрыт статус, красный - ошибка.

Если pystray или Pillow не установлены, трей просто не включается, а
программа работает как обычно.
"""

import os
import threading
import webbrowser

import logger as applog
import updater
from config import BASE_DIR
from runtime import RUNTIME

_COLORS = {
    "green": (63, 185, 80),
    "gray": (128, 138, 152),
    "red": (248, 81, 73),
    "yellow": (217, 162, 27),
}


def available():
    try:
        import pystray  # noqa: F401
        from PIL import Image  # noqa: F401
        return True
    except Exception:  # noqa: BLE001
        return False


def make_image(color):
    from PIL import Image, ImageDraw

    size = 64
    image = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    draw = ImageDraw.Draw(image)
    draw.ellipse((2, 2, size - 2, size - 2), fill=_COLORS.get(color, _COLORS["gray"]) + (255,))
    draw.polygon([(14, 31), (50, 16), (40, 50), (30, 38)], fill=(255, 255, 255, 255))
    return image


# ----------------------------------------------------------- окно консоли
def _console_hwnd():
    if os.name != "nt":
        return 0
    try:
        import ctypes

        return int(ctypes.windll.kernel32.GetConsoleWindow())
    except Exception:  # noqa: BLE001
        return 0


def can_hide_console():
    return (not RUNTIME.background) and bool(_console_hwnd())


def set_console_visible(visible):
    """
    Показывает или прячет окно CMD. Возвращает True, если команда выполнена.
    В Windows Terminal (вкладки) окно может не скрыться: тогда запускайте
    START_BACKGROUND.bat - он работает вообще без окна.
    """
    hwnd = _console_hwnd()
    if not hwnd:
        return False
    try:
        import ctypes

        ctypes.windll.user32.ShowWindow(hwnd, 5 if visible else 0)
        if visible:
            ctypes.windll.user32.SetForegroundWindow(hwnd)
        RUNTIME.console_hidden = not visible
        return True
    except Exception:  # noqa: BLE001
        return False


# --------------------------------------------------------------------- трей
class Tray(object):
    def __init__(self, settings):
        self.settings = settings
        self.icon = None
        self._last = (None, None)
        self._thread = None

    # ---- действия меню
    def _open_web(self, icon=None, item=None):
        if RUNTIME.web_url:
            webbrowser.open(RUNTIME.web_url)
        else:
            self.notify("Веб-панель выключена в настройках.")

    def _toggle_console(self, icon=None, item=None):
        set_console_visible(RUNTIME.console_hidden)

    def _toggle_pause(self, icon=None, item=None):
        RUNTIME.paused = not RUNTIME.paused

    def _open_folder(self, icon=None, item=None):
        try:
            os.startfile(BASE_DIR)  # type: ignore[attr-defined]
        except Exception:  # noqa: BLE001
            pass

    def _check_updates(self, icon=None, item=None):
        def run():
            info = updater.check(self.settings.get("update_url"))
            RUNTIME.update_info = info
            self.notify(info.get("message", ""))

        threading.Thread(target=run, daemon=True).start()

    def _exit(self, icon=None, item=None):
        RUNTIME.stop.set()
        self.stop()

    # ---- сборка
    def _menu(self):
        import pystray

        items = [
            pystray.MenuItem("Открыть веб-панель", self._open_web, default=True),
        ]
        if can_hide_console():
            items.append(
                pystray.MenuItem(
                    lambda item: "Показать консоль" if RUNTIME.console_hidden else "Скрыть консоль",
                    self._toggle_console,
                )
            )
        items.extend(
            [
                pystray.MenuItem(
                    lambda item: "Продолжить мониторинг" if RUNTIME.paused else "Пауза",
                    self._toggle_pause,
                ),
                pystray.MenuItem("Проверить обновления", self._check_updates),
                pystray.MenuItem("Открыть папку программы", self._open_folder),
                pystray.Menu.SEPARATOR,
                pystray.MenuItem("Выход", self._exit),
            ]
        )
        return pystray.Menu(*items)

    def notify(self, message, title="Telegram Monitor"):
        try:
            if self.icon is not None and message:
                self.icon.notify(str(message)[:250], title)
        except Exception:  # noqa: BLE001
            pass

    def start(self):
        """Запускает трей в отдельном потоке. Возвращает True при успехе."""
        if not available():
            return False
        try:
            import pystray

            self.icon = pystray.Icon(
                "TelegramMonitor", make_image(RUNTIME.color), RUNTIME.summary, self._menu()
            )
            self._thread = threading.Thread(target=self.icon.run, name="tray", daemon=True)
            self._thread.start()
            threading.Thread(target=self._refresh_loop, name="tray-refresh", daemon=True).start()
            RUNTIME.tray_active = True
            return True
        except Exception as exc:  # noqa: BLE001
            applog.warning("Tray could not start: %s", exc)
            RUNTIME.tray_active = False
            return False

    def _refresh_loop(self):
        while not RUNTIME.stop.wait(2.0):
            current = (RUNTIME.color, RUNTIME.summary)
            if current == self._last or self.icon is None:
                continue
            self._last = current
            try:
                self.icon.icon = make_image(current[0])
                self.icon.title = current[1][:120]
            except Exception:  # noqa: BLE001
                pass

    def stop(self):
        RUNTIME.tray_active = False
        if self.icon is not None:
            try:
                self.icon.stop()
            except Exception:  # noqa: BLE001
                pass
            self.icon = None
