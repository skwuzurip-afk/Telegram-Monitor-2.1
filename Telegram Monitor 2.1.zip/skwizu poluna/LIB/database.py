# -*- coding: utf-8 -*-
"""
Telegram Monitor 2.0 - SQLite-хранилище.

Таблицы:
  events    - журнал событий;
  sessions  - завершённые видимые онлайн-сессии;
  photos    - архив аватарок (файл + photo_id + время);
  app_state - сохранённое состояние цели (защита от дублей);
  meta      - служебные данные (версия схемы).

Время хранится в локальном поясе: строка "ГГГГ-ММ-ДД ЧЧ:ММ:СС" и Unix-время.
"""

import os
import sqlite3
import time
from datetime import datetime

TS_FORMAT = "%Y-%m-%d %H:%M:%S"

# Типы событий
STATUS_ONLINE = "STATUS_ONLINE"
STATUS_OFFLINE = "STATUS_OFFLINE"
STATUS_HIDDEN = "STATUS_HIDDEN"
STATUS_UNAVAILABLE = "STATUS_UNAVAILABLE"
LAST_SEEN = "LAST_SEEN"
FIRST_NAME = "FIRST_NAME"
LAST_NAME = "LAST_NAME"
USERNAME = "USERNAME"
BIO = "BIO"
PHOTO = "PHOTO"
TARGET_CHANGED = "TARGET_CHANGED"

EVENT_TYPES = (
    STATUS_ONLINE,
    STATUS_OFFLINE,
    STATUS_HIDDEN,
    STATUS_UNAVAILABLE,
    LAST_SEEN,
    FIRST_NAME,
    LAST_NAME,
    USERNAME,
    BIO,
    PHOTO,
    TARGET_CHANGED,
)


def ts_now():
    return datetime.now().strftime(TS_FORMAT)


def ts_str(moment):
    return moment.strftime(TS_FORMAT)


def parse_ts(text):
    if not text:
        return None
    try:
        return datetime.strptime(str(text), TS_FORMAT)
    except (TypeError, ValueError):
        return None


class Database(object):
    def __init__(self, path):
        self.path = path
        parent = os.path.dirname(path)
        if parent:
            os.makedirs(parent, exist_ok=True)
        self.conn = sqlite3.connect(path, timeout=30)
        try:
            self.conn.row_factory = sqlite3.Row
            self.conn.execute("PRAGMA journal_mode=WAL;")
            self.conn.execute("PRAGMA synchronous=NORMAL;")
            self._create_schema()
        except Exception:
            # Повреждённый файл: закрываем соединение, иначе Windows
            # не даст переименовать его в резервную копию.
            try:
                self.conn.close()
            except sqlite3.Error:
                pass
            raise

    # ---------------------------------------------------------------- схема
    def _create_schema(self):
        self.conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS events (
                id        INTEGER PRIMARY KEY AUTOINCREMENT,
                ts        TEXT NOT NULL,
                epoch     INTEGER NOT NULL,
                type      TEXT NOT NULL,
                old_value TEXT,
                new_value TEXT,
                duration  INTEGER
            );

            CREATE TABLE IF NOT EXISTS sessions (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                start_ts    TEXT NOT NULL,
                start_epoch INTEGER NOT NULL,
                end_ts      TEXT,
                end_epoch   INTEGER,
                duration    INTEGER
            );

            CREATE TABLE IF NOT EXISTS photos (
                id        INTEGER PRIMARY KEY AUTOINCREMENT,
                ts        TEXT NOT NULL,
                epoch     INTEGER NOT NULL,
                photo_id  TEXT,
                filename  TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS app_state (
                key   TEXT PRIMARY KEY,
                value TEXT
            );

            CREATE TABLE IF NOT EXISTS meta (
                key   TEXT PRIMARY KEY,
                value TEXT
            );

            CREATE INDEX IF NOT EXISTS idx_events_epoch ON events(epoch);
            CREATE INDEX IF NOT EXISTS idx_events_type  ON events(type);
            """
        )
        self.conn.execute(
            "INSERT OR IGNORE INTO meta (key, value) VALUES ('schema_version', '2')"
        )
        self.conn.commit()

    def check_integrity(self):
        """Быстрая проверка целостности. Возвращает (ok, message)."""
        try:
            row = self.conn.execute("PRAGMA quick_check;").fetchone()
            value = row[0] if row else ""
            if str(value).lower() == "ok":
                return True, "ok"
            return False, str(value)
        except sqlite3.Error as exc:
            return False, str(exc)

    # -------------------------------------------------------------- события
    def add_event(self, etype, old_value=None, new_value=None, duration=None, ts=None):
        if ts is None:
            ts = ts_now()
        epoch = int(time.time())
        cur = self.conn.execute(
            "INSERT INTO events (ts, epoch, type, old_value, new_value, duration) "
            "VALUES (?, ?, ?, ?, ?, ?)",
            (ts, epoch, etype, old_value, new_value, duration),
        )
        self.conn.commit()
        return cur.lastrowid

    def get_events(self, limit=100, offset=0, newest_first=True):
        order = "DESC" if newest_first else "ASC"
        rows = self.conn.execute(
            "SELECT id, ts, epoch, type, old_value, new_value, duration "
            "FROM events ORDER BY epoch %s, id %s LIMIT ? OFFSET ?" % (order, order),
            (int(limit), int(offset)),
        ).fetchall()
        return [dict(row) for row in rows]

    def events_between(self, epoch_from, epoch_to, limit=200000):
        rows = self.conn.execute(
            "SELECT id, ts, epoch, type, old_value, new_value, duration "
            "FROM events WHERE epoch >= ? AND epoch <= ? "
            "ORDER BY epoch ASC, id ASC LIMIT ?",
            (int(epoch_from), int(epoch_to), int(limit)),
        ).fetchall()
        return [dict(row) for row in rows]

    def search_events(self, text=None, etype=None, epoch_from=None, epoch_to=None, limit=300):
        sql = (
            "SELECT id, ts, epoch, type, old_value, new_value, duration "
            "FROM events WHERE 1=1"
        )
        params = []
        if text:
            sql += (
                " AND (type LIKE ? OR COALESCE(old_value, '') LIKE ? "
                "OR COALESCE(new_value, '') LIKE ?)"
            )
            pattern = "%" + text + "%"
            params.extend([pattern, pattern, pattern])
        if etype:
            sql += " AND type = ?"
            params.append(etype)
        if epoch_from is not None:
            sql += " AND epoch >= ?"
            params.append(int(epoch_from))
        if epoch_to is not None:
            sql += " AND epoch <= ?"
            params.append(int(epoch_to))
        sql += " ORDER BY epoch DESC, id DESC LIMIT ?"
        params.append(int(limit))
        rows = self.conn.execute(sql, params).fetchall()
        return [dict(row) for row in rows]

    def count_events(self):
        row = self.conn.execute("SELECT COUNT(*) AS n FROM events").fetchone()
        return int(row["n"]) if row else 0

    def get_last_was_online(self):
        row = self.conn.execute(
            "SELECT new_value FROM events "
            "WHERE type IN ('LAST_SEEN', 'STATUS_OFFLINE') AND new_value IS NOT NULL "
            "ORDER BY epoch DESC, id DESC LIMIT 1"
        ).fetchone()
        return row["new_value"] if row else None

    # --------------------------------------------------------------- сессии
    def add_session(self, start_dt, end_dt, duration):
        self.conn.execute(
            "INSERT INTO sessions (start_ts, start_epoch, end_ts, end_epoch, duration) "
            "VALUES (?, ?, ?, ?, ?)",
            (
                ts_str(start_dt),
                int(start_dt.timestamp()),
                ts_str(end_dt),
                int(end_dt.timestamp()),
                int(duration),
            ),
        )
        self.conn.commit()

    def sessions_between(self, epoch_from, epoch_to):
        rows = self.conn.execute(
            "SELECT id, start_ts, start_epoch, end_ts, end_epoch, duration "
            "FROM sessions WHERE start_epoch <= ? "
            "AND (end_epoch IS NULL OR end_epoch >= ?) "
            "ORDER BY start_epoch ASC",
            (int(epoch_to), int(epoch_from)),
        ).fetchall()
        return [dict(row) for row in rows]

    # --------------------------------------------------------------- фотографии
    def add_photo(self, photo_id, filename, ts=None):
        if ts is None:
            ts = ts_now()
        self.conn.execute(
            "INSERT INTO photos (ts, epoch, photo_id, filename) VALUES (?, ?, ?, ?)",
            (ts, int(time.time()), "" if photo_id is None else str(photo_id), filename),
        )
        self.conn.commit()

    def get_photos(self, limit=200):
        rows = self.conn.execute(
            "SELECT id, ts, photo_id, filename FROM photos "
            "ORDER BY epoch DESC, id DESC LIMIT ?",
            (int(limit),),
        ).fetchall()
        return [dict(row) for row in rows]

    def get_photo_by_id(self, photo_id):
        """Возвращает запись об уже сохранённой аватарке с таким photo_id."""
        if not photo_id:
            return None
        row = self.conn.execute(
            "SELECT id, ts, photo_id, filename FROM photos "
            "WHERE photo_id = ? ORDER BY id DESC LIMIT 1",
            (str(photo_id),),
        ).fetchone()
        return dict(row) if row else None

    def count_photos(self):
        row = self.conn.execute("SELECT COUNT(*) AS n FROM photos").fetchone()
        return int(row["n"]) if row else 0

    # ------------------------------------------------------------- состояние
    def get_state(self, key, default=None):
        row = self.conn.execute(
            "SELECT value FROM app_state WHERE key = ?", (key,)
        ).fetchone()
        if row is None:
            return default
        return row["value"]

    def set_state(self, key, value):
        self.set_state_many({key: value})

    def set_state_many(self, mapping):
        self.conn.executemany(
            "INSERT INTO app_state (key, value) VALUES (?, ?) "
            "ON CONFLICT(key) DO UPDATE SET value = excluded.value",
            [(str(key), "" if value is None else str(value)) for key, value in mapping.items()],
        )
        self.conn.commit()

    def save_cycle(self, events, state):
        """
        Атомарно сохраняет события и новое состояние цели одной транзакцией.
        Это защищает от дублей, если программа будет закрыта между записями.
        """
        epoch = int(time.time())
        rows = []
        for event in events or []:
            rows.append(
                (
                    event.get("ts") or ts_now(),
                    epoch,
                    event.get("type"),
                    event.get("old_value"),
                    event.get("new_value"),
                    event.get("duration"),
                )
            )
        state_rows = [
            (str(key), "" if value is None else str(value))
            for key, value in (state or {}).items()
        ]
        try:
            with self.conn:
                if rows:
                    self.conn.executemany(
                        "INSERT INTO events (ts, epoch, type, old_value, new_value, duration) "
                        "VALUES (?, ?, ?, ?, ?, ?)",
                        rows,
                    )
                if state_rows:
                    self.conn.executemany(
                        "INSERT INTO app_state (key, value) VALUES (?, ?) "
                        "ON CONFLICT(key) DO UPDATE SET value = excluded.value",
                        state_rows,
                    )
        except sqlite3.Error:
            self.conn.rollback()
            raise

    def reset_tracking_state(self):
        self.conn.execute("DELETE FROM app_state")
        self.conn.commit()

    # ----------------------------------------------------------------- сервис
    def backup(self, backup_dir=None):
        from config import DATA_DIR

        target_dir = backup_dir or os.path.join(DATA_DIR, "backups")
        os.makedirs(target_dir, exist_ok=True)
        name = "history_backup_%s.db" % datetime.now().strftime("%Y%m%d_%H%M%S")
        destination = os.path.join(target_dir, name)
        try:
            self.conn.execute("PRAGMA wal_checkpoint(FULL);")
        except sqlite3.Error:
            pass
        dst = sqlite3.connect(destination)
        try:
            self.conn.backup(dst)
        finally:
            dst.close()
        return destination

    def close(self):
        try:
            self.conn.commit()
        except sqlite3.Error:
            pass
        try:
            self.conn.close()
        except sqlite3.Error:
            pass


def _looks_like_lock_error(message):
    text = str(message or "").lower()
    markers = (
        "locked",
        "busy",
        "readonly",
        "read-only",
        "unable to open",
        "permission denied",
    )
    return any(marker in text for marker in markers)


def open_database_safe(path, log=None):
    """
    Открывает базу. Если файл повреждён, откладывает его рядом
    (history.corrupt_ГГГГММДД_ЧЧММСС.db) и создаёт новую пустую базу.

    Если база занята другим процессом или файл недоступен, файл
    НЕ переименовывается: ошибка пробрасывается вызывающему коду.

    Возвращает (db, warning_message|None).
    """
    try:
        db = Database(path)
        ok, message = db.check_integrity()
        if ok:
            return db, None
        db.close()
        raise sqlite3.DatabaseError(message)
    except sqlite3.DatabaseError as exc:
        if _looks_like_lock_error(exc):
            raise
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        corrupt_path = "%s.corrupt_%s" % (os.path.splitext(path)[0], stamp)
        try:
            if os.path.isfile(path):
                os.replace(path, corrupt_path)
            for suffix in ("-wal", "-shm"):
                sidecar = path + suffix
                if os.path.isfile(sidecar):
                    os.replace(sidecar, corrupt_path + suffix)
        except OSError:
            raise
        db = Database(path)
        text = (
            "База данных была повреждена и заменена новой. "
            "Старый файл сохранён как %s" % os.path.basename(corrupt_path)
        )
        if log:
            log(text)
        return db, text

