# -*- coding: utf-8 -*-
"""
Telegram Monitor 2.1 - веб-панель.

Сервер слушает ТОЛЬКО 127.0.0.1 (доступ с этого компьютера) и проверяет
заголовок Host, чтобы страницы из интернета не могли читать данные через
подмену DNS. Страница одна (LIB/panel.html), данные отдаются как JSON.

Для галереи из CONFIG.bat и «снимка» панели без запущенной программы
используется export_static(): HTML со встроенными данными.
"""

import json
import mimetypes
import os
import threading
import urllib.parse
import webbrowser
from datetime import datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

import logger as applog
from analytics import SAFE_NAME_RE, build_payload
from config import EXPORTS_DIR, LIB_DIR, ensure_dirs, get_targets
from runtime import RUNTIME

PANEL_PATH = os.path.join(LIB_DIR, "panel.html")
DATA_MARK = "/*__TM_DATA__*/"


def _read_template():
    with open(PANEL_PATH, "r", encoding="utf-8") as fh:
        return fh.read()


def _safe_json(payload):
    text = json.dumps(payload, ensure_ascii=False)
    return text.replace("</", "<\\/").replace("\u2028", "\\u2028").replace("\u2029", "\\u2029")


def _server_url_for(tinfo, name):
    return "/avatar/%s/%s" % (tinfo["id"], urllib.parse.quote(name))


def export_static(settings, path=None):
    """Сохраняет панель как отдельный HTML-файл (с данными на момент экспорта)."""
    ensure_dirs()
    if path is None:
        path = os.path.join(
            EXPORTS_DIR, "dashboard_%s.html" % datetime.now().strftime("%Y%m%d_%H%M%S")
        )
    base_dir = os.path.dirname(os.path.abspath(path))

    def url_for(tinfo, name):
        full = os.path.join(tinfo["avatars_dir"], name)
        try:
            rel = os.path.relpath(full, base_dir)
        except ValueError:  # другой диск Windows
            rel = full
        return urllib.parse.quote(rel.replace(os.sep, "/"))

    payload = build_payload(settings, url_for, runtime=None)
    html = _read_template().replace(
        DATA_MARK, "window.TM_STATIC=true;window.TM_DATA=%s;" % _safe_json(payload), 1
    )
    with open(path, "w", encoding="utf-8") as fh:
        fh.write(html)
    return path


def open_in_browser(path):
    try:
        return webbrowser.open("file:///" + os.path.abspath(path).replace(os.sep, "/"))
    except Exception:  # noqa: BLE001
        return False


class PanelServer(object):
    def __init__(self, settings, port):
        self.settings = settings
        self.requested_port = int(port)
        self.httpd = None
        self.thread = None
        self.port = None
        self.url = ""

    def _make_handler(self):
        settings = self.settings
        owner = self

        class Handler(BaseHTTPRequestHandler):
            protocol_version = "HTTP/1.0"
            server_version = "TelegramMonitorPanel"

            def log_message(self, fmt, *args):  # тихий режим
                return

            def _host_ok(self):
                host = (self.headers.get("Host") or "").strip().lower()
                allowed = {
                    "127.0.0.1:%d" % owner.port,
                    "localhost:%d" % owner.port,
                    "[::1]:%d" % owner.port,
                }
                return host in allowed

            def _send(self, code, body, ctype, extra=None):
                self.send_response(code)
                self.send_header("Content-Type", ctype)
                self.send_header("Content-Length", str(len(body)))
                self.send_header("X-Content-Type-Options", "nosniff")
                self.send_header("Referrer-Policy", "no-referrer")
                for key, value in (extra or {}).items():
                    self.send_header(key, value)
                self.end_headers()
                self.wfile.write(body)

            def do_GET(self):  # noqa: N802
                if not self._host_ok():
                    self._send(403, b"Forbidden", "text/plain; charset=utf-8")
                    return
                parsed = urllib.parse.urlparse(self.path)
                route = parsed.path
                try:
                    if route in ("/", "/index.html"):
                        html = _read_template().replace(DATA_MARK, "", 1)
                        self._send(200, html.encode("utf-8"), "text/html; charset=utf-8",
                                   {"Cache-Control": "no-store"})
                    elif route == "/api/data":
                        payload = build_payload(settings, _server_url_for, runtime=RUNTIME)
                        self._send(200, _safe_json(payload).encode("utf-8"),
                                   "application/json; charset=utf-8", {"Cache-Control": "no-store"})
                    elif route.startswith("/avatar/"):
                        self._avatar(route)
                    else:
                        self._send(404, b"Not found", "text/plain; charset=utf-8")
                except Exception as exc:  # noqa: BLE001
                    applog.warning("Web panel error: %s", exc)
                    self._send(500, b"Internal error", "text/plain; charset=utf-8")

            def _avatar(self, route):
                parts = route.split("/")  # ['', 'avatar', tid, name]
                if len(parts) != 4:
                    self._send(404, b"Not found", "text/plain; charset=utf-8")
                    return
                tid = urllib.parse.unquote(parts[2])
                name = urllib.parse.unquote(parts[3])
                if not SAFE_NAME_RE.match(name):
                    self._send(404, b"Not found", "text/plain; charset=utf-8")
                    return
                for tinfo in get_targets(settings):
                    if tinfo["id"] != tid:
                        continue
                    root = os.path.realpath(tinfo["avatars_dir"])
                    full = os.path.realpath(os.path.join(root, name))
                    if os.path.dirname(full) == root and os.path.isfile(full):
                        with open(full, "rb") as fh:
                            data = fh.read()
                        ctype = mimetypes.guess_type(full)[0] or "application/octet-stream"
                        self._send(200, data, ctype, {"Cache-Control": "max-age=3600"})
                        return
                self._send(404, b"Not found", "text/plain; charset=utf-8")

        return Handler

    def start(self):
        """Запускает сервер. При занятом порте пробует следующие 10 портов."""
        last_error = None
        for port in range(self.requested_port, self.requested_port + 10):
            self.port = port
            try:
                httpd = ThreadingHTTPServer(("127.0.0.1", port), self._make_handler())
            except OSError as exc:
                last_error = exc
                continue
            httpd.daemon_threads = True
            self.httpd = httpd
            self.url = "http://127.0.0.1:%d/" % port
            self.thread = threading.Thread(target=httpd.serve_forever, name="webpanel", daemon=True)
            self.thread.start()
            return True, self.url
        return False, str(last_error)

    def stop(self):
        if self.httpd is not None:
            try:
                self.httpd.shutdown()
                self.httpd.server_close()
            except Exception:  # noqa: BLE001
                pass
            self.httpd = None
