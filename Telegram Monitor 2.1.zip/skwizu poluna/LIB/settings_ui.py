# -*- coding: utf-8 -*-
"""
Telegram Monitor 2.0 - интерактивное меню CONFIG.bat.

Все настройки сохраняются в DATA/settings.json сразу после изменения.
Секреты (api_hash, телефон) при просмотре показываются частично.
"""

import os
from datetime import datetime

import autostart
import history as history_view
import logger as applog
import notifier as notifier_mod
import settings_io
import statistics
import updater
import webpanel
from config import (
    APP_VERSION,
    MAX_INTERVAL,
    MIN_INTERVAL,
    RECOMMENDED_INTERVAL,
    SESSION_NAME,
    SETTINGS_PATH,
    add_target,
    current_interval,
    display_target,
    ensure_dirs,
    get_targets,
    is_configured,
    is_target_set,
    load_settings,
    mask_phone,
    mask_secret,
    mask_token,
    normalize_target,
    on_off,
    remove_target,
    replace_target,
    save_settings,
    valid_bot_token,
    validate_interval,
)
from database import open_database_safe, parse_ts


# --------------------------------------------------------------------- вывод
def out(text=""):
    try:
        print(text, flush=True)
    except (UnicodeEncodeError, OSError):
        try:
            print(str(text).encode("ascii", "replace").decode("ascii"), flush=True)
        except Exception:  # noqa: BLE001
            pass


def _ask(prompt, default=None, allow_empty=False):
    suffix = ""
    if default is not None and str(default) != "":
        suffix = " [%s]" % default
    while True:
        try:
            value = input(prompt + suffix + ": ").strip()
        except (EOFError, KeyboardInterrupt):
            return None
        if value:
            return value
        if allow_empty:
            return ""
        if default is not None and str(default) != "":
            return str(default)
        out("Значение не может быть пустым.")


def _ask_int(prompt, minimum, maximum, default=None):
    while True:
        raw = _ask(prompt, default)
        if raw is None:
            return None
        try:
            number = int(raw)
        except ValueError:
            out("Введите целое число.")
            continue
        if not (minimum <= number <= maximum):
            out("Допустимое значение: от %d до %d." % (minimum, maximum))
            continue
        return number


def _mask_phone(phone):
    return mask_phone(phone)


def _save(settings):
    save_settings(settings)
    applog.info("Settings saved to %s", SETTINGS_PATH)


# ------------------------------------------------------------ поля настроек
def edit_api_id(settings):
    current = int(settings.get("api_id") or 0) or None
    value = _ask_int("Telegram API ID", 1, 9999999999, current)
    if value is None:
        return
    settings["api_id"] = value
    _save(settings)
    out("API ID сохранён: %d" % value)
    out("После смены API ID может потребоваться повторный вход в Telegram.")


def edit_api_hash(settings):
    current = str(settings.get("api_hash") or "")
    out("Текущий API HASH: %s" % mask_secret(current))
    value = _ask("Telegram API HASH (32 символа)")
    if value is None:
        return
    value = value.strip()
    if len(value) < 30:
        out("API HASH выглядит некорректно: ожидается 32 символа.")
        return
    settings["api_hash"] = value
    _save(settings)
    out("API HASH сохранён (в файле; при просмотре маскируется).")
    out("После смены API HASH может потребоваться повторный вход в Telegram.")


def edit_phone(settings):
    current = str(settings.get("phone") or "") or None
    while True:
        raw = _ask("Номер телефона в формате +79991234567", current)
        if raw is None:
            return
        clean = "".join(ch for ch in raw if ch not in " -()")
        if not (clean.startswith("+") and clean[1:].isdigit() and len(clean) >= 8):
            out("Введите номер в международном формате, например +79991234567.")
            continue
        break
    settings["phone"] = clean
    _save(settings)
    out("Номер телефона сохранён: %s" % _mask_phone(clean))


def edit_interval(settings):
    out("")
    out("Интервал проверки - как часто программа запрашивает статус и профиль.")
    out("Допустимый диапазон: %d-%d сек. Рекомендуется %d сек. и больше."
        % (MIN_INTERVAL, MAX_INTERVAL, RECOMMENDED_INTERVAL))
    out("Слишком частые запросы Telegram может временно ограничить (FloodWait).")
    while True:
        raw = _ask("Интервал проверки в секундах", str(current_interval(settings)))
        if raw is None:
            return
        value = validate_interval(raw)
        if value is None:
            out("Некорректное значение. Введите число от %d до %d."
                % (MIN_INTERVAL, MAX_INTERVAL))
            continue
        break
    settings["interval_seconds"] = value
    _save(settings)
    out("Интервал сохранён: %d сек." % value)
    out("Изменение применяется при следующем запуске START.bat.")
    if value < 30:
        out("Внимание: интервал меньше 30 сек. повышает риск ограничений Telegram.")
    applog.info("Interval changed to %d sec", value)


def toggle(settings, key, title):
    settings[key] = not bool(settings.get(key))
    _save(settings)
    out("%s: %s" % (title, on_off(settings[key])))


# ------------------------------------------------------------------ автозапуск
def autostart_menu():
    while True:
        out("")
        out("АВТОЗАПУСК ПРИ ВХОДЕ В WINDOWS: %s" % autostart.status_text())
        out("1 - включить: окно CMD с рамкой")
        out("2 - включить: фон, только значок в трее")
        out("3 - отключить")
        out("0 - назад")
        try:
            choice = input("Выберите пункт: ").strip()
        except EOFError:
            return
        if choice in ("1", "2"):
            ok, message = autostart.enable(background=(choice == "2"))
            out(message)
            if ok:
                applog.info("Autostart enabled (%s)", "background" if choice == "2" else "console")
        elif choice == "3":
            ok, message = autostart.disable()
            out(message)
            if ok:
                applog.info("Autostart disabled")
        elif choice in ("0", "q", "назад"):
            return


# -------------------------------------------------------------------- просмотр
def show_settings(settings):
    config_ready = is_configured(settings)
    target_ready = is_target_set(settings)
    session_file = SESSION_NAME + ".session"
    out("")
    out("=" * 54)
    out("              ТЕКУЩИЕ НАСТРОЙКИ")
    out("=" * 54)
    out("API ID:              %s" % (settings.get("api_id") or "(не задано)"))
    out("API HASH:            %s" % mask_secret(settings.get("api_hash")))
    out("PHONE:               %s" % _mask_phone(settings.get("phone")))
    for tinfo in get_targets(settings):
        out("TARGET:              %s%s%s" % (
            display_target(tinfo["target"]),
            " (%s)" % tinfo["label"] if tinfo["label"] else "",
            "" if tinfo["enabled"] else "  [выключена]"))
    if not settings.get("targets"):
        out("TARGET:              NOT SET")
    out("INTERVAL:            %d sec" % current_interval(settings))
    out("TRACK STATUS:        %s" % on_off(settings.get("track_status")))
    out("TRACK PROFILE:       %s" % on_off(settings.get("track_profile")))
    out("AVATAR HISTORY:      %s" % on_off(settings.get("avatar_history")))
    out("SAVE HISTORY:        %s" % on_off(settings.get("save_history")))
    out("PRINT EVENTS:        %s" % on_off(settings.get("print_events")))
    out("WINDOWS AUTOSTART:   %s" % autostart.status_text())
    out("BOT NOTIFICATIONS:   %s  (token %s, chats: %d)" % (
        on_off(settings.get("notify_enabled")), mask_token(settings.get("bot_token")),
        len(settings.get("notify_chat_ids") or [])))
    out("WEB PANEL:           %s  (port %s)" % (on_off(settings.get("web_enabled")), settings.get("web_port")))
    out("TRAY:                %s  (start hidden: %s)" % (
        on_off(settings.get("tray_enabled")), on_off(settings.get("start_hidden"))))
    out("UPDATE CHECK:        %s  (%s)" % (
        on_off(settings.get("update_check")), settings.get("update_url") or "адрес не задан"))
    out("VERSION:             %s" % APP_VERSION)
    out("API CONFIGURED:      %s" % ("YES" if config_ready else "NO"))
    out("TARGET CONFIGURED:   %s" % ("YES" if target_ready else "NO"))
    out("TELEGRAM SESSION:    %s" % ("FOUND" if os.path.isfile(session_file) else "NOT FOUND"))
    out("=" * 54)
    out("SETTINGS FILE:       %s" % SETTINGS_PATH)
    for tinfo in get_targets(settings):
        out("DATABASE:            %s" % tinfo["db_path"])
        out("AVATARS:             %s" % tinfo["avatars_dir"])
    out("")


# ------------------------------------------------------- история и статистика
def _open_db(path=None):
    if path is None:
        targets = get_targets(load_settings())
        if not targets:
            return None, None
        path = targets[0]["db_path"]
    try:
        return open_database_safe(path, log=lambda text: out("[!] " + text))
    except Exception as exc:  # noqa: BLE001
        out("[!] Не удалось открыть базу данных: %s" % exc)
        return None, None


def _pick_target(settings):
    """Выбор цели для просмотра истории. Возвращает tinfo или None."""
    targets = get_targets(settings)
    if not targets:
        out("Цели не заданы.")
        return None
    if len(targets) == 1:
        return targets[0]
    out("")
    for number, tinfo in enumerate(targets, 1):
        out("  %d - %s" % (number, display_target(tinfo["target"])))
    try:
        raw = input("Какая цель [1]: ").strip() or "1"
    except EOFError:
        return None
    if raw.isdigit() and 1 <= int(raw) <= len(targets):
        return targets[int(raw) - 1]
    out("Нет такой цели.")
    return None


def _run_with_db(action, tinfo=None):
    path = tinfo["db_path"] if tinfo else get_targets(load_settings())[0]["db_path"]
    db, warning = _open_db(path)
    if db is None:
        return
    if warning:
        out("[!] " + warning)
    try:
        action(db)
    finally:
        db.close()


def history_menu(settings):
    while True:
        out("")
        out("ИСТОРИЯ")
        out("1 - просмотр истории")
        out("2 - поиск")
        out("3 - статистика (день / неделя)")
        out("4 - архив аватарок")
        out("5 - экспорт в TXT")
        out("6 - экспорт в CSV")
        out("7 - резервная копия базы")
        out("0 - назад")
        try:
            choice = input("Выберите пункт: ").strip()
        except EOFError:
            return
        if choice in ("0", "q", "назад"):
            return
        if choice not in ("1", "2", "3", "4", "5", "6", "7"):
            continue
        tinfo = _pick_target(load_settings())
        if tinfo is None:
            continue
        label = display_target(tinfo["target"])
        if choice == "1":
            _run_with_db(lambda db: history_view.view_history(db), tinfo)
        elif choice == "2":
            _run_with_db(lambda db: history_view.search_history(db), tinfo)
        elif choice == "3":
            _run_with_db(lambda db: statistics.show_stats(db), tinfo)
        elif choice == "4":
            _run_with_db(lambda db: history_view.view_photo_archive(db, tinfo["avatars_dir"]), tinfo)
        elif choice == "5":
            _run_with_db(lambda db: _do_export(db, label, "txt"), tinfo)
        elif choice == "6":
            _run_with_db(lambda db: _do_export(db, label, "csv"), tinfo)
        elif choice == "7":
            _run_with_db(_do_backup, tinfo)


def _do_export(db, target, kind):
    if db.count_events() == 0:
        out("Журнал пуст - экспортировать нечего.")
        return
    try:
        if kind == "csv":
            path = statistics.export_csv(db, target)
        else:
            path = statistics.export_txt(db, target)
        out("Экспорт сохранён: %s" % path)
        applog.info("History exported to %s", path)
    except OSError as exc:
        out("[!] Не удалось сохранить экспорт: %s" % exc)
        applog.error("Export failed: %s", exc)


def _do_backup(db):
    try:
        path = db.backup()
        out("Резервная копия создана: %s" % path)
        applog.info("Database backup created: %s", path)
    except Exception as exc:  # noqa: BLE001
        out("[!] Не удалось создать копию: %s" % exc)
        applog.error("Backup failed: %s", exc)


# --------------------------------------------------------------- мастер настройки
def run_setup_wizard(settings):
    """
    Пошаговая первичная настройка. Вызывается из START.bat, если
    настройки ещё не заполнены.
    """
    out("")
    out("=" * 54)
    out("         ПЕРВИЧНАЯ НАСТРОЙКА TELEGRAM MONITOR")
    out("=" * 54)
    out("")
    out("Понадобятся api_id и api_hash (бесплатно):")
    out("  1) Откройте https://my.telegram.org и войдите под своим номером.")
    out('  2) Раздел "API development tools" - создайте приложение.')
    out("  3) Скопируйте api_id (число) и api_hash (32 символа).")
    out("")
    out("Вход выполняется под ВАШИМ аккаунтом Telegram.")
    out("")

    current_id = int(settings.get("api_id") or 0) or None
    api_id = _ask_int("Telegram API ID", 1, 9999999999, current_id)
    if api_id is None:
        return False

    while True:
        api_hash = _ask("Telegram API HASH (32 символа)", settings.get("api_hash") or None)
        if api_hash is None:
            return False
        api_hash = api_hash.strip()
        if len(api_hash) >= 30:
            break
        out("API HASH выглядит некорректно: ожидается 32 символа.")

    while True:
        phone = _ask(
            "Номер телефона в формате +79991234567",
            settings.get("phone") or None,
        )
        if phone is None:
            return False
        phone = "".join(ch for ch in phone if ch not in " -()")
        if phone.startswith("+") and phone[1:].isdigit() and len(phone) >= 8:
            break
        out("Введите номер в международном формате, например +79991234567.")

    while True:
        raw_target = _ask(
            "Username отслеживаемого аккаунта (например @durov)",
            normalize_target(settings.get("target")) or None,
        )
        if raw_target is None:
            return False
        target = normalize_target(raw_target)
        if target:
            break
        out("Username не может быть пустым.")

    while True:
        raw_interval = _ask(
            "Интервал проверки в секундах (%d-%d)" % (MIN_INTERVAL, MAX_INTERVAL),
            str(current_interval(settings)),
        )
        if raw_interval is None:
            return False
        interval = validate_interval(raw_interval)
        if interval is not None:
            break
        out("Некорректное значение. Введите число от %d до %d."
            % (MIN_INTERVAL, MAX_INTERVAL))

    settings["api_id"] = api_id
    settings["api_hash"] = api_hash
    settings["phone"] = phone
    if not any(t["target"].lower() == target.lower() for t in settings.get("targets") or []):
        add_target(settings, target)
    settings["interval_seconds"] = interval
    _save(settings)

    out("")
    out("Настройки сохранены: %s" % SETTINGS_PATH)
    out("Интервал: %d сек." % interval)
    if interval < 30:
        out("Внимание: интервал меньше 30 сек. повышает риск ограничений Telegram.")
    out("")
    return True


# ---------------------------------------------------------------- главное меню
def run_config_menu():
    ensure_dirs()
    settings = load_settings()

    try:
        while True:
            settings = load_settings()
            out("")
            out("=" * 54)
            out("              TELEGRAM MONITOR - CONFIG")
            out("=" * 54)
            out("TARGETS:  %d     INTERVAL: %d sec     VERSION: %s"
                % (len(settings.get("targets") or []), current_interval(settings), APP_VERSION))
            out("")
            out("  1 - Telegram API ID")
            out("  2 - Telegram API HASH")
            out("  3 - Phone number")
            out("  4 - Targets (tracked accounts) .... %d" % len(settings.get("targets") or []))
            out("  5 - Check interval")
            out("  6 - Track status .................. %s" % on_off(settings.get("track_status")))
            out("  7 - Track profile changes ......... %s" % on_off(settings.get("track_profile")))
            out("  8 - Avatar history ................ %s" % on_off(settings.get("avatar_history")))
            out("  9 - Save history to database ...... %s" % on_off(settings.get("save_history")))
            out(" 10 - Print events in CMD ........... %s" % on_off(settings.get("print_events")))
            out(" 11 - Windows autostart ............. %s" % autostart.status_text())
            out(" 12 - View current settings")
            out(" 13 - History / search / statistics / export")
            out(" 14 - Bot notifications ............ %s" % on_off(settings.get("notify_enabled")))
            out(" 15 - Web panel .................... %s" % on_off(settings.get("web_enabled")))
            out(" 16 - Tray / background ............ %s" % on_off(settings.get("tray_enabled")))
            out(" 17 - Avatar gallery (open in browser)")
            out(" 18 - Import / export settings")
            out(" 19 - Check for updates")
            out("  0 - Exit")
            try:
                choice = input("Выберите пункт: ").strip()
            except EOFError:
                return

            if choice == "1":
                edit_api_id(settings)
            elif choice == "2":
                edit_api_hash(settings)
            elif choice == "3":
                edit_phone(settings)
            elif choice == "4":
                targets_menu()
            elif choice == "5":
                edit_interval(settings)
            elif choice == "6":
                toggle(settings, "track_status", "TRACK STATUS")
            elif choice == "7":
                toggle(settings, "track_profile", "TRACK PROFILE")
            elif choice == "8":
                toggle(settings, "avatar_history", "AVATAR HISTORY")
            elif choice == "9":
                toggle(settings, "save_history", "SAVE HISTORY")
            elif choice == "10":
                toggle(settings, "print_events", "PRINT EVENTS")
            elif choice == "11":
                autostart_menu()
            elif choice == "12":
                show_settings(load_settings())
            elif choice == "13":
                history_menu(load_settings())
            elif choice == "14":
                notify_menu()
            elif choice == "15":
                web_menu()
            elif choice == "16":
                tray_menu()
            elif choice == "17":
                gallery_action()
            elif choice == "18":
                io_menu()
            elif choice == "19":
                update_menu()
            elif choice in ("0", "q", "exit", "выход"):
                return
            else:
                out("Неизвестный пункт меню.")
    finally:
        pass


# ===================================================================== цели
def _reset_state_for(tinfo, settings):
    """Закрывает старую видимую сессию и очищает состояние цели в её базе."""
    db, _ = _open_db(tinfo["db_path"])
    if db is None:
        return
    try:
        start_dt = parse_ts(db.get_state("online_since"))
        if start_dt is not None and settings.get("save_history"):
            duration = max(0, int((datetime.now() - start_dt).total_seconds()))
            db.add_session(start_dt, datetime.now(), duration)
        db.reset_tracking_state()
    finally:
        db.close()


def _index_arg(parts, count):
    if len(parts) >= 2 and parts[1].isdigit() and 1 <= int(parts[1]) <= count:
        return int(parts[1]) - 1
    out("Укажите номер цели, например: d 2")
    return None


def targets_menu():
    while True:
        settings = load_settings()
        targets = settings.get("targets") or []
        out("")
        out("ЦЕЛИ - отслеживаемые аккаунты (максимум 10)")
        for number, entry in enumerate(targets, 1):
            out("  %d - %s%s%s" % (
                number, display_target(entry["target"]),
                "  [%s]" % entry["label"] if entry["label"] else "",
                "" if entry["enabled"] else "  (выключена)"))
        if not targets:
            out("  (пока нет ни одной цели)")
        out("")
        out("  a        - добавить цель")
        out("  d N      - удалить цель N (история на диске остаётся)")
        out("  c N      - сменить username цели N (состояние сбрасывается)")
        out("  t N      - включить/выключить цель N")
        out("  l N      - задать метку (имя для уведомлений)")
        out("  0        - назад")
        out("Изменения применяются при следующем запуске START.bat.")
        try:
            raw = input("Команда: ").strip()
        except EOFError:
            return
        parts = raw.split()
        if not parts:
            continue
        cmd = parts[0].lower()
        if cmd in ("0", "q", "назад"):
            return
        if cmd == "a":
            value = _ask("Username, ссылка t.me/... или числовой ID")
            if value is None:
                continue
            label = _ask("Метка (необязательно)", allow_empty=True) or ""
            ok, message = add_target(settings, value, label)
            if ok:
                _save(settings)
            out(message)
            continue
        index = _index_arg(parts, len(targets))
        if index is None:
            continue
        if cmd == "d":
            ok, message = remove_target(settings, index)
            if ok:
                _save(settings)
            out(message)
        elif cmd == "c":
            value = _ask("Новый username", normalize_target(targets[index]["target"]) or None)
            if value is None:
                continue
            tinfo = get_targets(settings)[index]
            ok, message = replace_target(settings, index, value)
            if ok:
                _reset_state_for(tinfo, settings)
                _save(settings)
            out(message)
        elif cmd == "t":
            targets[index]["enabled"] = not targets[index]["enabled"]
            _save(settings)
            out("Цель %s: %s" % (display_target(targets[index]["target"]),
                                 "включена" if targets[index]["enabled"] else "выключена"))
        elif cmd == "l":
            value = _ask("Метка", targets[index]["label"] or None, allow_empty=True)
            if value is None:
                continue
            targets[index]["label"] = value[:40]
            _save(settings)
            out("Метка сохранена.")


# ================================================================ уведомления
def notify_menu():
    while True:
        settings = load_settings()
        out("")
        out("УВЕДОМЛЕНИЯ ЧЕРЕЗ TELEGRAM-БОТА: %s" % on_off(settings.get("notify_enabled")))
        out("Токен: %s" % mask_token(settings.get("bot_token")))
        out("Получатели (chat_id): %s" % (", ".join(settings.get("notify_chat_ids") or []) or "(нет)"))
        out("")
        out("  1 - токен бота (создайте бота у @BotFather)")
        out("  2 - получатели: добавить / удалить / найти автоматически")
        out("  3 - включить/выключить уведомления")
        out("  4 - что присылать: статус %s, профиль %s, аватарки %s, фото %s" % (
            on_off(settings.get("notify_status")), on_off(settings.get("notify_profile")),
            on_off(settings.get("notify_photo")), on_off(settings.get("notify_send_photo"))))
        out("  5 - отправить тестовое сообщение")
        out("  0 - назад")
        try:
            choice = input("Выберите пункт: ").strip()
        except EOFError:
            return
        if choice == "1":
            value = _ask("Токен бота (вида 123456:ABC...)")
            if value is None:
                continue
            if not valid_bot_token(value):
                out("Токен выглядит некорректно.")
                continue
            ok, info = notifier_mod.check_token(value.strip())
            if not ok:
                out("Токен не принят: %s" % info)
                out("Если связи с api.telegram.org нет, проверьте интернет/VPN.")
                continue
            settings["bot_token"] = value.strip()
            _save(settings)
            out("Токен сохранён. Бот: %s" % info)
            out("Теперь откройте бота в Telegram и нажмите /start, затем пункт 2.")
        elif choice == "2":
            _chat_ids_menu(settings)
        elif choice == "3":
            if not settings.get("notify_enabled") and not (
                settings.get("bot_token") and settings.get("notify_chat_ids")
            ):
                out("Сначала задайте токен (1) и хотя бы одного получателя (2).")
                continue
            toggle(settings, "notify_enabled", "NOTIFICATIONS")
        elif choice == "4":
            for key, title in (("notify_status", "Статус (онлайн/офлайн)"),
                               ("notify_profile", "Имя, username, описание"),
                               ("notify_photo", "Смена аватарки"),
                               ("notify_send_photo", "Прикладывать фото: было и стало")):
                answer = input("%s [сейчас %s] (y/n/Enter - без изменений): " % (
                    title, on_off(settings.get(key)))).strip().lower()
                if answer in ("y", "д", "1"):
                    settings[key] = True
                elif answer in ("n", "н", "0"):
                    settings[key] = False
            _save(settings)
            out("Сохранено.")
        elif choice == "5":
            if not (settings.get("bot_token") and settings.get("notify_chat_ids")):
                out("Нужны токен и получатели.")
                continue
            for chat, ok, text in notifier_mod.send_test(settings["bot_token"], settings["notify_chat_ids"]):
                out("  %s: %s - %s" % (chat, "OK" if ok else "ОШИБКА", text))
        elif choice in ("0", "q", "назад"):
            return


def _chat_ids_menu(settings):
    out("")
    out("a - добавить chat_id вручную; f - найти чаты, написавшие боту; d - удалить; 0 - назад")
    try:
        cmd = input("Команда: ").strip().lower()
    except EOFError:
        return
    ids = list(settings.get("notify_chat_ids") or [])
    if cmd == "a":
        value = _ask("chat_id (число; для канала @name)")
        if value and value not in ids:
            settings["notify_chat_ids"] = ids + [value]
            _save(settings)
            settings_after = load_settings()
            if value not in settings_after["notify_chat_ids"]:
                out("chat_id выглядит некорректно.")
            else:
                out("Получатель добавлен.")
    elif cmd == "f":
        if not settings.get("bot_token"):
            out("Сначала задайте токен.")
            return
        out("Напишите вашему боту /start в Telegram, затем нажмите Enter.")
        input("")
        found = notifier_mod.discover_chats(settings["bot_token"])
        if not found:
            out("Чатов не найдено. Проверьте, что вы нажали /start именно у этого бота.")
            return
        for number, (chat_id, name) in enumerate(found, 1):
            out("  %d - %s  %s" % (number, chat_id, name))
        raw = input("Какие добавить (номера через пробел, Enter - все): ").strip()
        chosen = found if not raw else [found[int(n) - 1] for n in raw.split()
                                        if n.isdigit() and 1 <= int(n) <= len(found)]
        for chat_id, _ in chosen:
            if chat_id not in ids:
                ids.append(chat_id)
        settings["notify_chat_ids"] = ids
        _save(settings)
        out("Получателей: %d" % len(load_settings()["notify_chat_ids"]))
    elif cmd == "d":
        if not ids:
            out("Список пуст.")
            return
        for number, chat_id in enumerate(ids, 1):
            out("  %d - %s" % (number, chat_id))
        raw = input("Номер для удаления: ").strip()
        if raw.isdigit() and 1 <= int(raw) <= len(ids):
            ids.pop(int(raw) - 1)
            settings["notify_chat_ids"] = ids
            _save(settings)
            out("Удалено.")


# ================================================================ веб и трей
def web_menu():
    while True:
        settings = load_settings()
        out("")
        out("ВЕБ-ПАНЕЛЬ: %s   порт: %s   автооткрытие в браузере: %s" % (
            on_off(settings.get("web_enabled")), settings.get("web_port"),
            on_off(settings.get("web_open_browser"))))
        out("Адрес при запуске: http://127.0.0.1:%s/  (доступна только на этом компьютере)" % settings.get("web_port"))
        out("  1 - включить/выключить")
        out("  2 - порт (1024-65535)")
        out("  3 - открывать браузер при запуске")
        out("  4 - сохранить снимок панели в HTML (без запущенной программы)")
        out("  0 - назад")
        try:
            choice = input("Выберите пункт: ").strip()
        except EOFError:
            return
        if choice == "1":
            toggle(settings, "web_enabled", "WEB PANEL")
        elif choice == "2":
            value = _ask_int("Порт", 1024, 65535, settings.get("web_port"))
            if value is not None:
                settings["web_port"] = value
                _save(settings)
                out("Порт сохранён: %d" % value)
        elif choice == "3":
            toggle(settings, "web_open_browser", "OPEN BROWSER")
        elif choice == "4":
            gallery_action(open_gallery=False)
        elif choice in ("0", "q", "назад"):
            return


def tray_menu():
    while True:
        settings = load_settings()
        out("")
        out("ТРЕЙ И ФОНОВАЯ РАБОТА")
        out("Значок в трее: %s   стартовать со скрытым окном: %s   автозапуск: %s" % (
            on_off(settings.get("tray_enabled")), on_off(settings.get("start_hidden")),
            autostart.status_text()))
        out("  1 - включить/выключить значок в трее")
        out("  2 - скрывать окно CMD при запуске (в Windows Terminal может не сработать)")
        out("  3 - автозапуск (окно или фон)")
        out("  0 - назад")
        out("Работа совсем без окна: запускайте START_BACKGROUND.bat.")
        try:
            choice = input("Выберите пункт: ").strip()
        except EOFError:
            return
        if choice == "1":
            toggle(settings, "tray_enabled", "TRAY")
        elif choice == "2":
            toggle(settings, "start_hidden", "START HIDDEN")
        elif choice == "3":
            autostart_menu()
        elif choice in ("0", "q", "назад"):
            return


# ============================================================ галерея и файлы
def gallery_action(open_gallery=True):
    settings = load_settings()
    if not settings.get("targets"):
        out("Цели не заданы.")
        return
    try:
        path = webpanel.export_static(settings)
    except OSError as exc:
        out("[!] Не удалось сохранить файл: %s" % exc)
        return
    out("Снимок панели сохранён: %s" % path)
    out("Вкладка \"Галерея аватарок\" показывает: было -> стало.")
    if open_gallery:
        webpanel.open_in_browser(path)


def io_menu():
    while True:
        out("")
        out("ИМПОРТ / ЭКСПОРТ НАСТРОЕК")
        out("  1 - экспорт БЕЗ секретов (безопасно показать другому)")
        out("  2 - экспорт ПОЛНЫЙ (api_hash, телефон, токен бота - хранить как пароль)")
        out("  3 - импорт из файла")
        out("  0 - назад")
        out("Сессия Telegram и история в файл настроек не входят.")
        try:
            choice = input("Выберите пункт: ").strip()
        except EOFError:
            return
        if choice in ("1", "2"):
            try:
                path = settings_io.export_settings(load_settings(), include_secrets=(choice == "2"))
            except OSError as exc:
                out("[!] Не удалось сохранить: %s" % exc)
                continue
            out("Файл сохранён: %s" % path)
            if choice == "2":
                out("Внимание: в файле есть секреты. Не отправляйте его посторонним.")
        elif choice == "3":
            _import_settings()
        elif choice in ("0", "q", "назад"):
            return


def _import_settings():
    raw = _ask("Путь к файлу настроек (можно перетащить файл в окно)")
    if raw is None:
        return
    try:
        imported, has_secrets = settings_io.read_settings_file(raw)
    except ValueError as exc:
        out("[!] %s" % exc)
        return
    current = load_settings()
    new_settings, changes = settings_io.plan_import(current, imported)
    if not changes:
        out("В файле нет отличий от текущих настроек.")
        return
    out("")
    out("БУДЕТ ИЗМЕНЕНО:")
    for key, old, new in changes:
        out("  %-18s %s  ->  %s" % (key, old, new))
    if not has_secrets:
        out("В файле нет секретов: api_id, api_hash, телефон и токен остаются прежними.")
    try:
        answer = input("Применить? Текущие настройки будут сохранены в DATA/backups [y/N]: ").strip().lower()
    except EOFError:
        return
    if answer not in ("y", "yes", "д", "да"):
        out("Импорт отменён.")
        return
    backup = settings_io.backup_current_settings()
    save_settings(new_settings)
    applog.info("Settings imported from %s", raw)
    out("Настройки импортированы." + (" Копия прежних: %s" % backup if backup else ""))
    out("Изменения применятся при следующем запуске START.bat.")


# ================================================================ обновления
def update_menu():
    while True:
        settings = load_settings()
        out("")
        out("ПРОВЕРКА ОБНОВЛЕНИЙ   текущая версия: %s" % APP_VERSION)
        out("Автопроверка: %s   адрес: %s" % (
            on_off(settings.get("update_check")), settings.get("update_url") or "(не задан)"))
        out("  1 - проверить сейчас")
        out("  2 - задать адрес (репозиторий GitHub или JSON по https)")
        out("  3 - включить/выключить автопроверку")
        out("  0 - назад")
        try:
            choice = input("Выберите пункт: ").strip()
        except EOFError:
            return
        if choice == "1":
            info = updater.check(settings.get("update_url"))
            out(info.get("message", ""))
            if info.get("status") == "new":
                if info.get("url"):
                    out("Скачать: %s" % info["url"])
                if info.get("notes"):
                    out("Что нового: %s" % info["notes"])
        elif choice == "2":
            value = _ask("Адрес (например https://github.com/владелец/репозиторий)", allow_empty=True)
            if value is None:
                continue
            settings["update_url"] = value
            _save(settings)
            out("Адрес сохранён." if value else "Адрес очищен.")
        elif choice == "3":
            toggle(settings, "update_check", "UPDATE CHECK")
        elif choice in ("0", "q", "назад"):
            return
