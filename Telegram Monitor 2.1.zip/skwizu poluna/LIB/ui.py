# -*- coding: utf-8 -*-
"""
Telegram Monitor 2.1 - рамка состояния в CMD.

Внизу окна рисуется аккуратная рамка с данными (username, телефон,
статус и краткая сводка). Она обновляется на месте через ANSI-коды
(Windows 10/11), а события печатаются выше неё: перед печатью рамка
стирается, после печати рисуется снова.

Если вывод перенаправлен в файл или консоль не поддерживает ANSI,
рамка автоматически отключается, остаётся обычный построчный журнал.
"""

import os
import re
import shutil
import sys
import unicodedata
from datetime import datetime

import logger as applog

UNICODE_BOX = {"tl": "┌", "tr": "┐", "bl": "└", "br": "┘", "h": "─", "v": "│", "ml": "├", "mr": "┤"}
ASCII_BOX = {"tl": "+", "tr": "+", "bl": "+", "br": "+", "h": "-", "v": "|", "ml": "+", "mr": "+"}

UNICODE_SYM = {"dot_on": "●", "dot_off": "○", "sep": "·", "ell": "…"}
ASCII_SYM = {"dot_on": "*", "dot_off": "o", "sep": "|", "ell": "..."}

STYLE_CODES = {
    "bold": "1",
    "dim": "2",
    "red": "31",
    "green": "32",
    "yellow": "33",
    "blue": "34",
    "magenta": "35",
    "cyan": "36",
    "gray": "90",
}

_ANSI_RE = re.compile(r"\x1b\[[0-9;?]*[A-Za-z]")


def strip_ansi(text):
    return _ANSI_RE.sub("", text)


# ----------------------------------------------------------------- текст
def cw(text):
    """Ширина строки в ячейках консоли."""
    total = 0
    for ch in text:
        if unicodedata.combining(ch) or ch in "\u200b\u200c\u200d\ufe0f":
            continue
        total += 2 if unicodedata.east_asian_width(ch) in ("W", "F") else 1
    return total


def clean_text(value):
    """
    Готовит имя/био к показу в рамке: убирает управляющие символы и эмодзи
    (CMD рисует их по-разному и ломает выравнивание), схлопывает пробелы.
    """
    text = "" if value is None else str(value)
    out = []
    for ch in text:
        code = ord(ch)
        if ch in "\r\n\t":
            out.append(" ")
        elif unicodedata.category(ch) in ("Cc", "Cf", "Cs", "Co"):
            continue
        elif code > 0xFFFF or 0x2600 <= code <= 0x27BF or 0xFE00 <= code <= 0xFE0F:
            continue
        else:
            out.append(ch)
    return re.sub(r"\s+", " ", "".join(out)).strip()


def truncate(text, max_width, ell="…"):
    if cw(text) <= max_width:
        return text
    limit = max(0, max_width - cw(ell))
    out = []
    width = 0
    for ch in text:
        step = cw(ch)
        if width + step > limit:
            break
        out.append(ch)
        width += step
    return "".join(out) + ell


def paint(text, style, color):
    if not color or not style or not text:
        return text
    codes = [STYLE_CODES[name] for name in style.split() if name in STYLE_CODES]
    if not codes:
        return text
    return "\x1b[%sm%s\x1b[0m" % (";".join(codes), text)


def fit_segments(segments, width, ell):
    """Обрезает список (текст, стиль) до заданной ширины."""
    result = []
    used = 0
    for index, (text, style) in enumerate(segments):
        room = width - used
        if room <= 0:
            break
        if cw(text) <= room:
            result.append((text, style))
            used += cw(text)
            continue
        result.append((truncate(text, room, ell), style))
        used = width
        break
    return result, used


# ---------------------------------------------------------------- рамка
def build_box(rows, width, ascii_only=False, color=True):
    """
    rows: список строк трёх видов:
      ("title", левый_текст, правый_текст)
      ("row", [(текст, стиль), ...])
      ("sep",)
    Возвращает список готовых строк (с ANSI-стилями, если color=True).
    """
    box = ASCII_BOX if ascii_only else UNICODE_BOX
    sym = ASCII_SYM if ascii_only else UNICODE_SYM
    inner = width - 4
    border = "gray"
    lines = []

    for row in rows:
        kind = row[0]
        if kind == "title":
            left = " %s " % row[1]
            right = " %s " % row[2] if len(row) > 2 and row[2] else ""
            room = width - 4
            if cw(left) + cw(right) > room - 1:
                left = truncate(left, max(4, room - cw(right) - 1), sym["ell"])
            fill = max(1, width - 4 - cw(left) - cw(right))
            line = (
                paint(box["tl"] + box["h"], border, color)
                + paint(left, "bold cyan", color)
                + paint(box["h"] * fill, border, color)
                + (paint(right, "gray", color) if right else "")
                + paint(box["h"] + box["tr"], border, color)
            )
            lines.append(line)
        elif kind == "sep":
            lines.append(paint(box["ml"] + box["h"] * (width - 2) + box["mr"], border, color))
        else:
            segments, used = fit_segments(row[1], inner, sym["ell"])
            body = "".join(paint(text, style, color) for text, style in segments)
            pad = " " * max(0, inner - used)
            lines.append(
                paint(box["v"], border, color) + " " + body + pad + " " + paint(box["v"], border, color)
            )
    lines.append(paint(box["bl"] + box["h"] * (width - 2) + box["br"], border, color))
    return lines


# ------------------------------------------------------------ окно консоли
def enable_vt():
    """Включает ANSI-последовательности в консоли Windows. True, если они работают."""
    if os.name != "nt":
        return True
    try:
        import ctypes

        kernel32 = ctypes.windll.kernel32
        handle = kernel32.GetStdHandle(-11)
        mode = ctypes.c_uint32()
        if not kernel32.GetConsoleMode(handle, ctypes.byref(mode)):
            return False
        if mode.value & 0x0004:
            return True
        return bool(kernel32.SetConsoleMode(handle, mode.value | 0x0004))
    except Exception:  # noqa: BLE001
        return False


class LiveBox(object):
    """Рамка внизу окна, которая перерисовывается на месте."""

    def __init__(self, stream=None, force=False, ascii_only=False):
        self.stream = stream if stream is not None else sys.stdout
        self.ascii_only = ascii_only
        self.lines = 0
        self.cursor_hidden = False
        self.rows = None
        self.enabled = False
        self.color = False
        self.fixed_size = None  # (колонки, строки) для тестов
        if force:
            self.enabled = True
            self.color = True
        else:
            try:
                tty = bool(self.stream is not None and self.stream.isatty())
            except Exception:  # noqa: BLE001
                tty = False
            if tty and enable_vt():
                self.enabled = True
                self.color = "NO_COLOR" not in os.environ

    def size(self):
        if self.fixed_size:
            return self.fixed_size
        try:
            term = shutil.get_terminal_size((100, 30))
            return term.columns, term.lines
        except Exception:  # noqa: BLE001
            return 100, 30

    def width(self):
        return max(46, min(self.size()[0] - 1, 80))

    def max_lines(self):
        return max(6, self.size()[1] - 2)

    def _write(self, text):
        try:
            self.stream.write(text)
            self.stream.flush()
        except Exception:  # noqa: BLE001
            self.enabled = False

    def render(self, rows):
        """Рисует или обновляет рамку на месте."""
        if not self.enabled or rows is None:
            return
        self.rows = rows
        frame = build_box(rows, self.width(), self.ascii_only, self.color)
        out = ""
        if not self.cursor_hidden:
            out += "\x1b[?25l"
            self.cursor_hidden = True
        if self.lines:
            out += "\x1b[%dA\r" % self.lines
        out += "".join(line + "\x1b[K\n" for line in frame)
        out += "\x1b[J"
        self._write(out)
        self.lines = len(frame)

    def redraw(self):
        if self.rows is not None:
            self.render(self.rows)

    def clear(self):
        """Стирает рамку, чтобы напечатать строку выше неё."""
        if not self.enabled or not self.lines:
            return
        self._write("\x1b[%dA\r\x1b[J" % self.lines)
        self.lines = 0

    def restore(self):
        """Возвращает курсор. Вызывается при выходе."""
        if self.enabled and self.cursor_hidden:
            self._write("\x1b[?25h")
            self.cursor_hidden = False


LIVE = LiveBox(stream=None, force=False)
LIVE.enabled = False


def init(ascii_only=False, background=False):
    """Создаёт рамку для текущего окна. В фоновом режиме рамка отключена."""
    global LIVE
    if background:
        LIVE = LiveBox(stream=None, force=False)
        LIVE.enabled = False
        return LIVE
    LIVE = LiveBox(stream=sys.stdout, ascii_only=ascii_only)
    return LIVE


def console(text=""):
    LIVE.clear()
    try:
        print(text, flush=True)
    except (UnicodeEncodeError, OSError, AttributeError):
        try:
            print(str(text).encode("ascii", "replace").decode("ascii"), flush=True)
        except Exception:  # noqa: BLE001
            pass


def service(text, level="info"):
    stamp = datetime.now().strftime("%H:%M:%S")
    if level == "warning":
        line = "[%s] [!] %s" % (stamp, text)
        applog.warning(text)
    elif level == "error":
        line = "[%s] [!] %s" % (stamp, text)
        applog.error(text)
    else:
        line = "[%s] [i] %s" % (stamp, text)
        applog.info(text)
    console(line)


# ------------------------------------------------------------- сводка
def _label(name):
    return (name.ljust(7), "gray")


_STATUS_STYLE = {
    "online": "bold green",
    "offline": "gray",
    "hidden": "yellow",
    "unavailable": "yellow",
    "connecting": "cyan",
    "checking": "cyan",
    "error": "bold red",
    "paused": "yellow",
    "unknown": "gray",
}


def _dot(kind, sym):
    if kind == "online":
        return (sym["dot_on"], "bold green")
    if kind in ("hidden", "unavailable", "paused"):
        return (sym["dot_on"], "yellow")
    if kind == "error":
        return (sym["dot_on"], "bold red")
    if kind in ("connecting", "checking"):
        return (sym["dot_off"], "cyan")
    return (sym["dot_off"], "gray")


def _target_rows(view, level, sym, single):
    kind = view.get("kind") or "unknown"
    style = _STATUS_STYLE.get(kind, "gray")
    title = clean_text(view.get("title") or "")
    name = clean_text(view.get("name") or "")
    sep = " %s " % sym["sep"]

    if level >= 2:
        segments = [_dot(kind, sym), (" " + title, "bold")]
        segments.append(("  " + (view.get("status") or ""), style))
        return [("row", segments)]

    head = [_dot(kind, sym), (" " + title, "bold")]
    if name:
        head.append(("  " + name, "gray"))
    rows = [("row", head)]
    rows.append(("row", [_label("STATUS"), (view.get("status") or "-", style)]))
    if level == 0:
        info = []
        if view.get("user_id"):
            info.append("ID %s" % view["user_id"])
        if view.get("phone"):
            info.append("TEL %s" % view["phone"])
        info.append("EVENTS %d" % int(view.get("events") or 0))
        info.append("AVATARS %d" % int(view.get("avatars") or 0))
        for badge in view.get("badges") or []:
            info.append(badge)
        rows.append(("row", [_label("INFO"), (sep.join(info), "")]))
        bio = clean_text(view.get("bio") or "")
        if single and bio:
            rows.append(("row", [_label("BIO"), (bio, "gray")]))
    return rows


def dashboard_rows(ctx, level=0):
    """Строки рамки для заданного уровня подробности (0 - полный, 2 - минимум)."""
    ascii_only = bool(ctx.get("ascii"))
    sym = ASCII_SYM if ascii_only else UNICODE_SYM
    sep = " %s " % sym["sep"]
    views = ctx.get("views") or []
    single = len(views) == 1

    rows = [("title", "%s %s" % (ctx.get("name", "TELEGRAM MONITOR"), ctx.get("version", "")),
             "UP " + ctx.get("uptime", "0s"))]

    account = [_label("PHONE"), (ctx.get("phone") or "-", "")]
    if ctx.get("me_username"):
        account.append((sep + "ACC @" + ctx["me_username"], "gray"))
    if level < 2:
        rows.append(("row", account))
        rows.append(("sep",))

    for index, view in enumerate(views):
        if index and level < 2:
            rows.append(("sep",))
        rows.extend(_target_rows(view, level, sym, single))
    if not views:
        rows.append(("row", [("No targets. Add one in CONFIG.bat (item 4).", "yellow")]))

    # нижняя часть: состояние проверки и модули
    state = ctx.get("check_state") or "OK"
    check_style = {
        "OK": "green",
        "CONNECTING": "cyan",
        "CHECKING": "cyan",
        "PAUSED": "yellow",
        "FAILED": "bold red",
    }.get(state, "")
    parts = []
    if ctx.get("check_time"):
        parts.append("[%s]" % ctx["check_time"])
    parts.append(state)
    if ctx.get("check_detail"):
        parts.append(ctx["check_detail"])
    if ctx.get("next_in") is not None and state != "PAUSED":
        parts.append("NEXT %ds" % max(0, int(ctx["next_in"])))
    check_line = (" ".join(parts[:1] + [parts[1]]) + "".join(sep + p for p in parts[2:]))

    modules = []
    bot = ctx.get("bot")
    if bot is not None:
        modules.append("BOT %s" % bot)
    if ctx.get("web"):
        modules.append("WEB %s" % ctx["web"])
    if ctx.get("tray"):
        modules.append("TRAY")
    if ctx.get("update"):
        modules.append(ctx["update"])
    modules_text = sep.join(modules) if modules else "no modules enabled"

    rows.append(("sep",))
    if level >= 2:
        rows.append(("row", [(check_line, check_style)]))
    else:
        rows.append(("row", [_label("CHECK"), (check_line, check_style)]))
        rows.append(("row", [_label("SYSTEM"), (modules_text, "gray")]))
    return rows


def build_dashboard(ctx, max_lines=30):
    """Выбирает самый подробный вид, который помещается в окно."""
    rows = None
    for level in (0, 1, 2):
        rows = dashboard_rows(ctx, level)
        if len(rows) + 1 <= max_lines:
            break
    return rows
