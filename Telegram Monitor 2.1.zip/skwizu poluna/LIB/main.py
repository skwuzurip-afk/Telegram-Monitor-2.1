# -*- coding: utf-8 -*-
"""
Telegram Monitor 2.1 - точка входа.

Режимы:
  python LIB/main.py config                 - меню настроек (CONFIG.bat);
  python LIB/main.py run                    - мониторинг в окне CMD (START.bat);
  python LIB/main.py run --background       - без окна, только трей
                                              (START_BACKGROUND.bat / pythonw).
"""

import importlib
import json
import os
import sys
import time
import webbrowser
from datetime import datetime

# pythonw запускает программу без консоли: stdout/stderr отсутствуют.
if sys.stdout is None:
    sys.stdout = open(os.devnull, "w", encoding="utf-8")
if sys.stderr is None:
    sys.stderr = open(os.devnull, "w", encoding="utf-8")
try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")
except (AttributeError, ValueError):
    pass

LIB_DIR = os.path.dirname(os.path.abspath(__file__))
BASE_DIR = os.path.dirname(LIB_DIR)
if LIB_DIR not in sys.path:
    sys.path.insert(0, LIB_DIR)

import logger as applog
import settings_io
import settings_ui
import ui
from config import (
    APP_NAME,
    APP_VERSION,
    DEFAULT_SETTINGS,
    LOCK_PATH,
    LOG_PATH,
    SETTINGS_PATH,
    current_interval,
    ensure_dirs,
    get_targets,
    is_configured,
    is_target_set,
    load_settings,
    mask_phone,
    save_settings,
)
from runtime import RUNTIME
from statistics import fmt_duration

EXIT_FROM_TRAY = 10  # START.bat не просит нажать клавишу после выхода из трея


# ------------------------------------------------------------------ служебное
def setup_environment():
    ensure_dirs()
    applog.setup_logging(LOG_PATH)


def message_box(text, title="Telegram Monitor"):
    """Окно сообщения для фонового режима (там нет консоли)."""
    applog.warning("%s", text)
    if os.name == "nt":
        try:
            import ctypes

            ctypes.windll.user32.MessageBoxW(0, str(text), str(title), 0x40)
            return
        except Exception:  # noqa: BLE001
            pass
    ui.console(text)


def telethon_available():
    try:
        importlib.import_module("telethon")
        return True, ""
    except Exception as exc:  # noqa: BLE001
        return False, str(exc)


def _acquire_lock():
    ensure_dirs()
    handle = open(LOCK_PATH, "a+", encoding="utf-8")
    try:
        import msvcrt
    except ImportError:
        return handle
    try:
        handle.write("lock")
        handle.flush()
        handle.seek(0)
        msvcrt.locking(handle.fileno(), msvcrt.LK_NBLCK, 1)
        handle.seek(0)
        handle.truncate()
        handle.write("pid=%d" % os.getpid())
        handle.flush()
        return handle
    except OSError:
        handle.close()
        return None


def _migrate_settings_file(settings):
    """
    Если в settings.json нет новых полей версии 2.1 (например, он от 2.0),
    сохраняет файл в новом формате. Старая версия копируется в DATA/backups.
    """
    if not os.path.isfile(SETTINGS_PATH):
        return
    try:
        with open(SETTINGS_PATH, "r", encoding="utf-8") as fh:
            raw = json.load(fh)
    except (OSError, ValueError):
        return
    if isinstance(raw, dict) and set(DEFAULT_SETTINGS) - set(raw):
        try:
            settings_io.backup_current_settings()
            save_settings(settings)
            applog.info("settings.json upgraded to the 2.1 format")
        except OSError as exc:
            applog.warning("Could not upgrade settings.json: %s", exc)


# ------------------------------------------------------------- рамка (HUD)
class Hud(object):
    """Собирает данные для рамки и перерисовывает её."""

    def __init__(self, settings):
        self.settings = settings
        self.workers = []
        self.mode = "connecting"  # connecting | monitor
        self.state = "CONNECTING"
        self.detail = "CONNECTING TO TELEGRAM"
        self.next_at = time.time() + current_interval(settings)
        self.me_username = ""

    def set_connecting(self, detail, wait=None):
        self.mode = "connecting"
        self.state = "CONNECTING"
        self.detail = detail
        self.next_at = time.time() + (wait if wait is not None else current_interval(self.settings))

    def _aggregate(self):
        """Состояние проверки по всем целям."""
        if RUNTIME.paused:
            return "PAUSED", "", None, None
        times = [w.last_check for w in self.workers if w.last_check]
        last = max(times) if times else None
        nexts = [w.next_due for w in self.workers]
        next_in = (min(nexts) - time.time()) if nexts else None
        for worker in self.workers:
            if worker.phase == "checking":
                return "CHECKING", worker.name(), last, next_in
        for worker in self.workers:
            if worker.phase == "error":
                return "FAILED", worker.detail, last, next_in
        if all(w.phase == "init" for w in self.workers) and self.workers:
            return "CONNECTING", "WAITING FOR FIRST CHECK", last, next_in
        return "OK", "", last, next_in

    def update_runtime(self, views):
        """Цвет и подсказка значка в трее."""
        if self.mode != "monitor":
            RUNTIME.color, RUNTIME.summary = "gray", "Telegram Monitor: подключение…"
            return
        kinds = [v["kind"] for v in views]
        if RUNTIME.paused:
            color = "yellow"
        elif "error" in kinds:
            color = "red"
        elif "online" in kinds:
            color = "green"
        elif any(kind in ("hidden", "unavailable") for kind in kinds):
            color = "yellow"
        else:
            color = "gray"
        parts = ["%s: %s" % (v["title"], v["status"].split(" · ")[0]) for v in views[:3]]
        text = "Telegram Monitor — " + ("; ".join(parts) if parts else "нет целей")
        if RUNTIME.paused:
            text += " (пауза)"
        RUNTIME.color, RUNTIME.summary = color, text

    def context(self):
        now = datetime.now()
        views = [worker.view(now) for worker in self.workers]
        if self.mode == "connecting":
            state, detail = self.state, self.detail
            last = now
            next_in = self.next_at - time.time()
        else:
            state, detail, last, next_in = self._aggregate()
        self.update_runtime(views)

        web = ""
        if RUNTIME.web_url:
            web = ":" + RUNTIME.web_url.rstrip("/").rsplit(":", 1)[-1]
        update = ""
        info = RUNTIME.update_info or {}
        if info.get("status") == "new":
            update = "UPDATE v%s" % info.get("latest")
        notifier = RUNTIME.notifier
        return {
            "name": APP_NAME,
            "version": APP_VERSION,
            "uptime": fmt_duration(int(time.time() - RUNTIME.started)),
            "phone": mask_phone(self.settings.get("phone")),
            "me_username": self.me_username,
            "views": views,
            "check_time": last.strftime("%H:%M:%S") if last else "",
            "check_state": state,
            "check_detail": detail,
            "next_in": next_in,
            "bot": notifier.badge() if notifier is not None else None,
            "web": web,
            "tray": RUNTIME.tray_active,
            "update": update,
            "ascii": bool(self.settings.get("ui_ascii")),
        }

    def render(self):
        if ui.LIVE.enabled:
            ui.LIVE.render(ui.build_dashboard(self.context(), ui.LIVE.max_lines()))
        else:
            self.update_runtime([w.view() for w in self.workers])


def _tick_wait(hud, seconds, detail):
    """Ожидание с живым обратным отсчётом в рамке. False, если запрошена остановка."""
    end = time.time() + seconds
    while time.time() < end:
        if RUNTIME.stop.is_set():
            return False
        hud.set_connecting(detail % max(0, int(end - time.time())), wait=end - time.time())
        hud.render()
        RUNTIME.stop.wait(1.0)
    return True


# ------------------------------------------------------------------- запуск
def run_monitor(background=False):
    setup_environment()
    RUNTIME.background = background
    ui.init(ascii_only=False, background=background)
    settings = load_settings()

    if not is_configured(settings) or not is_target_set(settings):
        if background:
            message_box(
                "Telegram Monitor не настроен. Запустите CONFIG.bat и заполните "
                "API ID, API HASH, телефон и хотя бы одну цель."
            )
            return 1
        if not settings_ui.run_setup_wizard(settings):
            ui.console("")
            ui.console("Monitoring was not started: setup is incomplete.")
            return 1
        settings = load_settings()
    _migrate_settings_file(settings)

    ui.init(ascii_only=bool(settings.get("ui_ascii")), background=background)

    available, import_error = telethon_available()
    if not available:
        ui.service("Telethon is not installed or cannot be loaded.", level="error")
        ui.console("Run CONFIG.bat or START.bat again: it installs dependencies automatically.")
        ui.console("Manual command: python -m pip install -r LIB\\requirements.txt")
        if import_error:
            applog.error("Telethon import error: %s", import_error)
        if background:
            message_box("Не установлен Telethon. Запустите START.bat один раз.")
        return 1

    lock_handle = _acquire_lock()
    if lock_handle is None:
        if background:
            applog.warning("Another instance is already running (background start skipped).")
        else:
            ui.service("Another Telegram Monitor instance is already running.", level="warning")
        return 1

    from engine import TargetWorker
    from notifier import Notifier
    from telegram_client import SessionInvalid, TelegramMonitorClient
    import tray as tray_module
    import updater
    import webpanel

    client = None
    workers = []
    tray = None
    panel = None
    exit_code = 0
    hud = Hud(settings)

    try:
        # --- трей (в фоновом режиме он обязателен: иначе не остановить программу)
        want_tray = bool(settings.get("tray_enabled")) or background
        if want_tray:
            tray = tray_module.Tray(settings)
            if not tray.start():
                tray = None
                if background:
                    message_box(
                        "Для фонового режима нужны pystray и Pillow. Запустите START.bat "
                        "один раз: он установит их автоматически."
                    )
                    return 1
                ui.service(
                    "Tray is unavailable (pystray/Pillow not installed). Running without it.",
                    level="warning",
                )
        if tray is not None and settings.get("start_hidden") and tray_module.can_hide_console():
            tray_module.set_console_visible(False)

        # --- уведомления через бота
        notifier = Notifier(settings)
        RUNTIME.notifier = notifier
        notifier.start()

        # --- веб-панель
        if settings.get("web_enabled"):
            panel = webpanel.PanelServer(settings, settings.get("web_port"))
            ok, info = panel.start()
            if ok:
                RUNTIME.web_url = info
                applog.info("Web panel: %s", info)
                if settings.get("web_open_browser") and not background:
                    webbrowser.open(info)
            else:
                ui.service("Web panel could not start: %s" % info, level="warning")
                panel = None

        # --- проверка обновлений (в фоне)
        def on_new_version(info):
            text = "Доступна новая версия %s." % info.get("latest")
            if info.get("url"):
                text += " " + info["url"]
            ui.service("Update available: %s %s" % (info.get("latest"), info.get("url") or ""))
            if tray is not None:
                tray.notify(text)
            if notifier.enabled:
                notifier.notify_system(text)

        updater.start_background(settings, on_new=on_new_version)

        # --- клиент и цели
        client = TelegramMonitorClient(settings)
        for tinfo in get_targets(settings, only_enabled=True):
            try:
                worker = TargetWorker(tinfo, settings, client)
            except Exception as exc:  # noqa: BLE001
                ui.service("Target %s could not be opened: %s" % (tinfo["target"], exc), level="error")
                continue
            if worker.warning:
                ui.service(worker.warning, level="warning")
            workers.append(worker)
        for index, worker in enumerate(workers):
            worker.multi = len(workers) > 1
            worker.next_due = time.time() + index * 2  # небольшой разнос по времени
        hud.workers = workers
        if not workers:
            ui.service("No enabled targets. Add one in CONFIG.bat (item 4).", level="error")
            return 1

        applog.info(
            "Monitor started. Targets: %s, interval: %d sec.",
            ", ".join(w.target for w in workers),
            current_interval(settings),
        )

        # --- подключение (бесконечные повторы: после загрузки Windows сети может не быть)
        hud.set_connecting("CONNECTING TO TELEGRAM")
        hud.render()
        attempt = 0
        delay = 5
        while True:
            attempt += 1
            ok, error = client.connect_once()
            if ok:
                break
            applog.warning("Connection error: %s", error)
            if attempt % 10 == 1:
                ui.service("Could not connect to Telegram: %s" % error, level="warning")
            if not _tick_wait(hud, delay, "RECONNECT IN %ds"):
                return EXIT_FROM_TRAY if RUNTIME.stop.is_set() else 0
            delay = min(delay * 2, 120)

        # --- вход в аккаунт
        if not client.is_authorized():
            if background:
                message_box(
                    "Сессия Telegram не авторизована. Запустите START.bat один раз, "
                    "введите код из Telegram, затем снова используйте фоновый режим."
                )
                return 1
            ui.LIVE.clear()
            ui.LIVE.restore()
            ui.console("")
            ui.console("Telegram session is not authorized.")
            ui.console("Enter the confirmation code from Telegram (and 2FA password if enabled).")
            if not client.sign_in_interactive(log=lambda text: ui.service(text, level="warning")):
                ui.service("Authorization failed. Monitoring was not started.", level="error")
                return 1
            ui.service("Signed in successfully.")
        hud.me_username = client.load_me()

        hud.mode = "monitor"
        hud.render()

        # --- главный цикл
        while not RUNTIME.stop.is_set():
            if not RUNTIME.paused:
                for worker in workers:
                    if RUNTIME.stop.is_set() or RUNTIME.paused:
                        break
                    if worker.next_due > time.time():
                        continue
                    worker.phase = "checking"
                    hud.render()
                    try:
                        result, wait = worker.poll()
                    except SessionInvalid:
                        text = (
                            "Telegram session is invalid (signed out on another device). "
                            "Start again and sign in."
                        )
                        ui.service(text, level="error")
                        if notifier.enabled:
                            notifier.notify_system("сессия Telegram недействительна, нужен повторный вход.")
                        if background:
                            message_box("Сессия Telegram недействительна. Запустите START.bat и войдите заново.")
                        RUNTIME.stop.set()
                        exit_code = 1
                        break
                    ui.LIVE.redraw()
                    if result == "flood":
                        until = time.time() + wait
                        for other in workers:
                            other.next_due = max(other.next_due, until)
                        break
                    RUNTIME.stop.wait(0.5)  # пауза между запросами к Telegram
            hud.render()
            RUNTIME.stop.wait(1.0)

        if exit_code == 0:
            exit_code = EXIT_FROM_TRAY if tray is not None else 0

    except KeyboardInterrupt:
        ui.console("")
        ui.service("Monitoring stopped by user (Ctrl+C). History is saved.")
        exit_code = 0
    except Exception as exc:  # noqa: BLE001 - последняя линия защиты
        applog.exception("Unexpected monitor error")
        ui.service("Unexpected error: %s" % exc, level="error")
        exit_code = 1
    finally:
        RUNTIME.stop.set()
        ui.LIVE.clear()
        ui.LIVE.restore()
        if RUNTIME.console_hidden:
            tray_module.set_console_visible(True)
        if tray is not None:
            tray.stop()
        if RUNTIME.notifier is not None:
            RUNTIME.notifier.stop()
        if panel is not None:
            panel.stop()
        if client is not None:
            client.disconnect()
        for worker in workers:
            worker.close()
        try:
            lock_handle.close()
        except Exception:  # noqa: BLE001
            pass
    return exit_code


def main():
    setup_environment()
    args = [argument.lower() for argument in sys.argv[1:]]
    if "config" in args:
        settings_ui.run_config_menu()
        return 0
    return run_monitor(background="--background" in args)


if __name__ == "__main__":
    try:
        sys.exit(main())
    except KeyboardInterrupt:
        ui.console("")
        ui.console("Stopped.")
        sys.exit(0)
