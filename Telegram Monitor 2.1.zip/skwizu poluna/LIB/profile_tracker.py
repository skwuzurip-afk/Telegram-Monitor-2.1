# -*- coding: utf-8 -*-
"""
Telegram Monitor 2.0 - отслеживание изменений публичного профиля.

Фиксируются first name, last name, username и bio. При изменении
сохраняются старое и новое значения. Аватарка обрабатывается отдельно
в avatar_tracker.py.
"""

from database import BIO, FIRST_NAME, LAST_NAME, USERNAME


FIELDS = (
    ("first_name", FIRST_NAME),
    ("last_name", LAST_NAME),
    ("username", USERNAME),
    ("bio", BIO),
)


def _norm(value):
    if value is None:
        return ""
    return str(value).strip()


class ProfileTracker(object):
    def process(self, prev, snap, track=True):
        """
        Возвращает (events, updates).

        prev  - сохранённое состояние цели;
        snap  - свежий снимок профиля;
        track - включено ли отслеживание профиля.
        """
        events = []
        updates = {}
        for field, event_type in FIELDS:
            old_value = _norm(prev.get(field))
            new_value = _norm(snap.get(field))
            updates[field] = new_value
            if track and old_value != new_value:
                events.append(
                    {
                        "type": event_type,
                        "old_value": old_value,
                        "new_value": new_value,
                    }
                )
        return events, updates
