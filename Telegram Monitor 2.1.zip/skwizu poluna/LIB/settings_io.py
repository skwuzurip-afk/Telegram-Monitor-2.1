# -*- coding: utf-8 -*-
"""
Telegram Monitor 2.1 - экспорт и импорт настроек.

Экспорт бывает двух видов:
  - БЕЗ секретов: нет api_id, api_hash, телефона и токена бота - файл
    можно безопасно показать другому человеку;
  - ПОЛНЫЙ: со всеми секретами - для переноса на другой компьютер.
    Хранить такой файл нужно как пароль.

Сессия Telegram (DATA/sessions) и история (базы, аватарки) в файл
настроек не попадают.

Импорт никогда не вставляет непроверенные данные: значения проходят
через config.sanitize_settings, неизвестные ключи игнорируются,
перед записью делается резервная копия текущего settings.json.
"""

import json
import os
import shutil
from datetime import datetime

from config import (
    APP_NAME,
    APP_VERSION,
    BACKUPS_DIR,
    DATA_DIR,
    EXPORTS_DIR,
    SECRET_KEYS,
    SETTINGS_PATH,
    ensure_dirs,
    mask_secret,
    mask_token,
    sanitize_settings,
)

FORMAT_ID = "telegram-monitor-settings"
MAX_FILE_BYTES = 256 * 1024


def export_settings(settings, include_secrets=False, path=None):
    """Сохраняет настройки в JSON. Возвращает путь к файлу."""
    ensure_dirs()
    clean = sanitize_settings(settings)
    payload = {}
    for key, value in clean.items():
        if key in SECRET_KEYS and not include_secrets:
            continue
        payload[key] = value
    document = {
        "_format": FORMAT_ID,
        "_app": "%s %s" % (APP_NAME, APP_VERSION),
        "_exported": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "_includes_secrets": bool(include_secrets),
        "settings": payload,
    }
    if path is None:
        suffix = "full" if include_secrets else "safe"
        path = os.path.join(
            EXPORTS_DIR,
            "settings_%s_%s.json" % (suffix, datetime.now().strftime("%Y%m%d_%H%M%S")),
        )
    with open(path, "w", encoding="utf-8") as fh:
        json.dump(document, fh, ensure_ascii=False, indent=2)
    return path


def read_settings_file(path):
    """
    Читает файл настроек. Возвращает (settings_dict, includes_secrets).
    Принимает и обычный settings.json из DATA, и экспорт этой программы.
    Бросает ValueError с понятным текстом.
    """
    path = os.path.abspath(str(path).strip().strip('"').strip("'"))
    if not os.path.isfile(path):
        raise ValueError("Файл не найден: %s" % path)
    if os.path.getsize(path) > MAX_FILE_BYTES:
        raise ValueError("Файл слишком большой для файла настроек.")
    try:
        with open(path, "r", encoding="utf-8-sig") as fh:
            document = json.load(fh)
    except (OSError, ValueError) as exc:
        raise ValueError("Не удалось прочитать JSON: %s" % exc)
    if not isinstance(document, dict):
        raise ValueError("Неверный формат файла.")

    if document.get("_format") == FORMAT_ID:
        body = document.get("settings")
        if not isinstance(body, dict):
            raise ValueError("В файле нет раздела settings.")
        return body, bool(document.get("_includes_secrets"))
    if any(key in document for key in ("interval_seconds", "targets", "target", "api_id")):
        return document, any(key in document for key in SECRET_KEYS)
    raise ValueError("Это не файл настроек Telegram Monitor.")


def _show(key, value):
    if key == "api_hash":
        return mask_secret(value)
    if key == "bot_token":
        return mask_token(value)
    if key == "phone":
        return mask_secret(value, visible=2)
    if key == "targets":
        return ", ".join(t["target"] for t in value) or "(нет)"
    if isinstance(value, list):
        return ", ".join(str(v) for v in value) or "(нет)"
    if isinstance(value, bool):
        return "ON" if value else "OFF"
    return str(value) if value not in ("", None) else "(пусто)"


def plan_import(current, imported_raw):
    """
    Готовит результат импорта.
    Возвращает (new_settings, changes), где changes - список (ключ, было, станет).
    Секреты, которых нет в файле, остаются прежними.
    """
    current = sanitize_settings(current)
    merged_source = dict(current)
    for key, value in imported_raw.items():
        merged_source[key] = value
    if "targets" not in imported_raw and "target" in imported_raw:
        merged_source["targets"] = []  # старый формат: цель возьмётся из "target"
    new_settings = sanitize_settings(merged_source)

    changes = []
    for key in new_settings:
        if key == "target":
            continue
        if new_settings.get(key) != current.get(key):
            changes.append((key, _show(key, current.get(key)), _show(key, new_settings.get(key))))
    return new_settings, changes


def backup_current_settings():
    """Копия текущего settings.json перед импортом. Возвращает путь или None."""
    if not os.path.isfile(SETTINGS_PATH):
        return None
    os.makedirs(BACKUPS_DIR, exist_ok=True)
    destination = os.path.join(
        BACKUPS_DIR, "settings_before_import_%s.json" % datetime.now().strftime("%Y%m%d_%H%M%S")
    )
    shutil.copy2(SETTINGS_PATH, destination)
    return destination


def default_dialog_dir():
    return EXPORTS_DIR if os.path.isdir(EXPORTS_DIR) else DATA_DIR
