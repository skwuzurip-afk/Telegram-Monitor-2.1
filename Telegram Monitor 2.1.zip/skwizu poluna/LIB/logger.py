# -*- coding: utf-8 -*-
"""
Telegram Monitor 2.0 - файловый журнал.

Пишет служебные сообщения и ошибки в LOGS/monitor.log.
Файл автоматически ротируется, чтобы не занимать диск бесконечно:
до 3 архивных файлов по 2 МБ.
"""

import logging
import os
from logging.handlers import RotatingFileHandler

LOGGER_NAME = "telegram_monitor"
_READY = False


def setup_logging(log_path):
    """Создаёт обработчик файла один раз за запуск процесса."""
    global _READY
    if _READY:
        return logging.getLogger(LOGGER_NAME)

    directory = os.path.dirname(log_path)
    if directory:
        os.makedirs(directory, exist_ok=True)

    logger = logging.getLogger(LOGGER_NAME)
    logger.setLevel(logging.INFO)
    logger.propagate = False

    if not any(isinstance(handler, RotatingFileHandler) for handler in logger.handlers):
        handler = RotatingFileHandler(
            log_path,
            maxBytes=2 * 1024 * 1024,
            backupCount=3,
            encoding="utf-8",
        )
        handler.setFormatter(
            logging.Formatter("%(asctime)s [%(levelname)s] %(message)s")
        )
        logger.addHandler(handler)

    _READY = True
    return logger


def get_logger():
    return logging.getLogger(LOGGER_NAME)


def info(message, *args):
    get_logger().info(message, *args)


def warning(message, *args):
    get_logger().warning(message, *args)


def error(message, *args):
    get_logger().error(message, *args)


def exception(message, *args):
    get_logger().exception(message, *args)
