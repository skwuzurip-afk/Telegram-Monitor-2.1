# -*- coding: utf-8 -*-
"""
Telegram Monitor 2.0 - отслеживание доступного статуса ONLINE / OFFLINE.

Учитываются только сведения, которые Telegram сам показывает вашему
аккаунту согласно настройкам приватности цели. Скрытый или приблизительный
статус не выдаётся за точный ONLINE/OFFLINE.
"""

from datetime import datetime

from database import (
    LAST_SEEN,
    STATUS_HIDDEN,
    STATUS_OFFLINE,
    STATUS_ONLINE,
    STATUS_UNAVAILABLE,
    parse_ts,
    ts_str,
)


class StatusTracker(object):
    def __init__(self, db):
        self.db = db

    def process(self, prev, snap, track=True, now=None, save_sessions=True):
        """
        prev  - сохранённое состояние цели (dict строк);
        snap  - свежий снимок из TelegramMonitorClient.get_snapshot();
        track - включено ли отслеживание статуса в настройках;
        save_sessions - записывать ли завершённые сессии в базу
                        (выключено вместе с сохранением истории).

        Возвращает (events, updates):
          events  - список событий для журнала;
          updates - новые значения полей состояния status/status_label/
                    was_online/online_since.
        """
        if now is None:
            now = datetime.now()

        old_status = (prev.get("status") or "").strip()
        old_label = (prev.get("status_label") or "").strip()
        old_was_online = (prev.get("was_online") or "").strip()
        start_dt = parse_ts(prev.get("online_since"))

        new_status = snap.get("status") or "unavailable"
        new_label = (snap.get("status_label") or "").strip()
        new_was_online = snap.get("was_online")

        updates = {
            "status": new_status,
            "status_label": new_label,
            "was_online": ts_str(new_was_online) if new_was_online else "",
            "online_since": "",
        }
        events = []

        if not track:
            # Отслеживание выключено: состояние обновляем, события не пишем.
            # Открытую видимую сессию корректно закрываем, чтобы она не «висела».
            if start_dt is not None:
                duration = max(0, int((now - start_dt).total_seconds()))
                if save_sessions:
                    self.db.add_session(start_dt, now, duration)
            return events, updates

        if new_status == "online":
            if old_status != "online":
                events.append({"type": STATUS_ONLINE})
            if start_dt is None:
                # Либо цель только что появилась, либо отслеживание включили,
                # когда она уже была в сети. Вторую сессию не открываем заново.
                start_dt = now
            updates["online_since"] = ts_str(start_dt)

        elif new_status == "offline":
            last_seen_text = ts_str(new_was_online) if new_was_online else ""
            if old_status == "online":
                duration = None
                if start_dt is not None:
                    end_dt = new_was_online or now
                    if end_dt < start_dt:
                        end_dt = now
                    if end_dt > now:
                        end_dt = now
                    duration = max(0, int((end_dt - start_dt).total_seconds()))
                    if save_sessions:
                        self.db.add_session(start_dt, end_dt, duration)
                events.append(
                    {
                        "type": STATUS_OFFLINE,
                        "new_value": last_seen_text,
                        "duration": duration,
                    }
                )
            elif old_status != "offline":
                events.append(
                    {"type": STATUS_OFFLINE, "new_value": last_seen_text}
                )
            else:
                # Статус не изменился, но время последнего визита могло
                # обновиться, если человек заходил между проверками.
                new_text = ts_str(new_was_online) if new_was_online else ""
                if new_text and new_text != old_was_online:
                    events.append(
                        {
                            "type": LAST_SEEN,
                            "old_value": old_was_online,
                            "new_value": new_text,
                        }
                    )

        elif new_status == "hidden":
            if old_status == "online":
                duration = None
                if start_dt is not None:
                    duration = max(0, int((now - start_dt).total_seconds()))
                    if save_sessions:
                        self.db.add_session(start_dt, now, duration)
                events.append(
                    {
                        "type": STATUS_HIDDEN,
                        "new_value": new_label,
                        "duration": duration,
                        "note": "visible session ended approximately",
                    }
                )
            elif old_status != "hidden":
                events.append({"type": STATUS_HIDDEN, "new_value": new_label})
            elif new_label != old_label:
                events.append(
                    {
                        "type": STATUS_HIDDEN,
                        "old_value": old_label,
                        "new_value": new_label,
                    }
                )

        else:  # unavailable
            if old_status == "online":
                duration = None
                if start_dt is not None:
                    duration = max(0, int((now - start_dt).total_seconds()))
                    if save_sessions:
                        self.db.add_session(start_dt, now, duration)
                events.append(
                    {
                        "type": STATUS_UNAVAILABLE,
                        "duration": duration,
                        "note": "visible session ended approximately",
                    }
                )
            elif old_status != "unavailable":
                events.append({"type": STATUS_UNAVAILABLE})

        return events, updates

    # ------------------------------------------------------------- запуск
    def close_stale_session(self, prev, continuity_window, save_sessions=True):
        """
        Закрывает сессию, которая осталась открытой с прошлого запуска,
        если программа была выключена дольше допустимого окна.

        Состояние в базе очищается в любом случае: иначе при следующем
        запуске та же сессия была бы записана повторно.

        Возвращает True, если сессия была закрыта.
        """
        if (prev.get("status") or "") != "online":
            return False
        start_dt = parse_ts(prev.get("online_since"))
        last_poll = parse_ts(prev.get("last_poll"))
        if start_dt is None:
            return False
        if last_poll is None:
            return False
        if (datetime.now() - last_poll).total_seconds() <= continuity_window:
            return False
        end_dt = last_poll if last_poll >= start_dt else start_dt
        duration = max(0, int((end_dt - start_dt).total_seconds()))
        if save_sessions:
            self.db.add_session(start_dt, end_dt, duration)
        self.db.set_state_many({"status": "", "online_since": ""})
        return True
