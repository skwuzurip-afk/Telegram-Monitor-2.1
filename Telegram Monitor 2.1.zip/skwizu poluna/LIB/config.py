# -*- coding: utf-8 -*-
"""
Telegram Monitor 2.1 - настройки и пути проекта.

Структура:
  TelegramMonitor/
    CONFIG.bat, START.bat, START_BACKGROUND.bat
    LIB/  - весь код
    DATA/ - settings.json, history*.db, avatars/, sessions/, exports/, backups/
    LOGS/ - monitor.log

Несколько целей: у каждой цели своя база history_<имя>.db и своя папка
аватарок. Первая цель из версии 2.0 продолжает использовать history.db
и DATA/avatars, поэтому старая история не теряется.
"""

import hashlib
import json
import os
import re

APP_NAME = "TELEGRAM MONITOR"
APP_VERSION = "2.1.0"

LIB_DIR = os.path.dirname(os.path.abspath(__file__))
BASE_DIR = os.path.dirname(LIB_DIR)

DATA_DIR = os.path.join(BASE_DIR, "DATA")
LOGS_DIR = os.path.join(BASE_DIR, "LOGS")
AVATARS_DIR = os.path.join(DATA_DIR, "avatars")
SESSIONS_DIR = os.path.join(DATA_DIR, "sessions")
EXPORTS_DIR = os.path.join(DATA_DIR, "exports")
BACKUPS_DIR = os.path.join(DATA_DIR, "backups")

SETTINGS_PATH = os.path.join(DATA_DIR, "settings.json")
DB_PATH = os.path.join(DATA_DIR, "history.db")  # база первой (старой) цели
LOG_PATH = os.path.join(LOGS_DIR, "monitor.log")
SESSION_NAME = os.path.join(SESSIONS_DIR, "account")
LOCK_PATH = os.path.join(DATA_DIR, "monitor.lock")

MIN_INTERVAL = 10
MAX_INTERVAL = 86400
RECOMMENDED_INTERVAL = 60
MAX_TARGETS = 10
DEFAULT_WEB_PORT = 8765

DEFAULT_SETTINGS = {
    "api_id": 0,
    "api_hash": "",
    "phone": "",
    "target": "",  # устаревшее поле: дублирует первую цель из "targets"
    "targets": [],
    "interval_seconds": RECOMMENDED_INTERVAL,
    "track_status": True,
    "track_profile": True,
    "avatar_history": True,
    "save_history": True,
    "print_events": True,
    # уведомления через вашего Telegram-бота
    "notify_enabled": False,
    "bot_token": "",
    "notify_chat_ids": [],
    "notify_status": True,
    "notify_profile": True,
    "notify_photo": True,
    "notify_send_photo": True,
    # веб-панель (только этот компьютер)
    "web_enabled": True,
    "web_port": DEFAULT_WEB_PORT,
    "web_open_browser": False,
    # трей
    "tray_enabled": True,
    "start_hidden": False,
    # обновления
    "update_check": True,
    "update_url": "",
    # вид рамки в CMD: True - только символы + - |
    "ui_ascii": False,
}

BOOL_KEYS = (
    "track_status",
    "track_profile",
    "avatar_history",
    "save_history",
    "print_events",
    "notify_enabled",
    "notify_status",
    "notify_profile",
    "notify_photo",
    "notify_send_photo",
    "web_enabled",
    "web_open_browser",
    "tray_enabled",
    "start_hidden",
    "update_check",
    "ui_ascii",
)

# Ключи, которые считаются секретными при экспорте настроек.
SECRET_KEYS = ("api_id", "api_hash", "phone", "bot_token")

_SAFE_DB_RE = re.compile(r"^[A-Za-z0-9_\-]{1,60}\.db$")
_SAFE_DIR_RE = re.compile(r"^[A-Za-z0-9_\-]{1,60}$")


def ensure_dirs():
    for directory in (
        DATA_DIR,
        LOGS_DIR,
        AVATARS_DIR,
        SESSIONS_DIR,
        EXPORTS_DIR,
        BACKUPS_DIR,
    ):
        os.makedirs(directory, exist_ok=True)


# ----------------------------------------------------------------- цели
def normalize_target(value):
    """'@name', 'name', 'https://t.me/name' -> 'name'."""
    if value is None:
        return ""
    text = str(value).strip()
    lowered = text.lower()
    for prefix in ("https://t.me/", "http://t.me/", "t.me/"):
        if lowered.startswith(prefix):
            text = text[len(prefix):]
            break
    text = text.strip().strip("/")
    if text.startswith("@"):
        text = text[1:]
    return text.strip()


def target_slug(target):
    """Короткое безопасное имя для файлов цели."""
    text = normalize_target(target).lower()
    if text.isdigit():
        return "id" + text[:30]
    slug = re.sub(r"[^a-z0-9_]", "", text)[:40]
    if not slug or len(slug) < len(text):
        digest = hashlib.sha1(text.encode("utf-8")).hexdigest()[:6]
        slug = (slug or "t") + "_" + digest
    return slug


def _make_entry(target, label="", enabled=True, db=None, avatars=None):
    target = normalize_target(target)
    slug = target_slug(target)
    if not (isinstance(db, str) and _SAFE_DB_RE.match(db)):
        db = "history_%s.db" % slug
    if avatars is None or (avatars and not _SAFE_DIR_RE.match(str(avatars))):
        avatars = slug
    return {
        "target": target,
        "label": str(label or "").strip()[:40],
        "enabled": bool(enabled),
        "db": db,
        "avatars": str(avatars),
    }


def _sanitize_targets(raw):
    result = []
    seen_targets = set()
    seen_dbs = set()
    if not isinstance(raw, list):
        raw = []
    for item in raw:
        if isinstance(item, str):
            item = {"target": item}
        if not isinstance(item, dict):
            continue
        target = normalize_target(item.get("target"))
        if not target or target.lower() in seen_targets:
            continue
        entry = _make_entry(
            target,
            label=item.get("label", ""),
            enabled=item.get("enabled", True),
            db=item.get("db"),
            avatars=item.get("avatars"),
        )
        # Две цели не должны делить одну базу.
        base = os.path.splitext(entry["db"])[0]
        counter = 2
        while entry["db"].lower() in seen_dbs:
            entry["db"] = "%s_%d.db" % (base, counter)
            counter += 1
        seen_targets.add(target.lower())
        seen_dbs.add(entry["db"].lower())
        result.append(entry)
        if len(result) >= MAX_TARGETS:
            break
    return result


def get_targets(settings, only_enabled=False):
    """Список целей с готовыми путями к базе и папке аватарок."""
    result = []
    for entry in settings.get("targets") or []:
        if only_enabled and not entry.get("enabled", True):
            continue
        avatars_sub = entry.get("avatars") or ""
        result.append(
            {
                "id": os.path.splitext(entry["db"])[0],
                "target": entry["target"],
                "label": entry.get("label") or "",
                "enabled": bool(entry.get("enabled", True)),
                "db_path": os.path.join(DATA_DIR, entry["db"]),
                "avatars_dir": os.path.join(AVATARS_DIR, avatars_sub)
                if avatars_sub
                else AVATARS_DIR,
            }
        )
    return result


def target_title(tinfo):
    """Короткое имя цели для заголовков и уведомлений."""
    label = (tinfo.get("label") or "").strip()
    if label:
        return label
    return display_target(tinfo.get("target"))


def add_target(settings, username, label=""):
    """Добавляет цель. Возвращает (успех, сообщение)."""
    target = normalize_target(username)
    if not target:
        return False, "Пустой username."
    targets = settings.setdefault("targets", [])
    if any(t["target"].lower() == target.lower() for t in targets):
        return False, "Такая цель уже есть в списке."
    if len(targets) >= MAX_TARGETS:
        return False, "Максимум целей: %d." % MAX_TARGETS
    entry = _make_entry(target, label=label)
    used = {t["db"].lower() for t in targets}
    base = os.path.splitext(entry["db"])[0]
    counter = 2
    while entry["db"].lower() in used:
        entry["db"] = "%s_%d.db" % (base, counter)
        counter += 1
    targets.append(entry)
    _sync_legacy_target(settings)
    return True, "Цель добавлена: %s" % display_target(target)


def remove_target(settings, index):
    targets = settings.get("targets") or []
    if not (0 <= index < len(targets)):
        return False, "Нет такой цели."
    removed = targets.pop(index)
    _sync_legacy_target(settings)
    return True, "Цель удалена из списка: %s. Файлы истории остались на диске." % (
        display_target(removed["target"])
    )


def replace_target(settings, index, username):
    """Меняет username у цели, сохраняя её базу. Возвращает (успех, сообщение)."""
    targets = settings.get("targets") or []
    if not (0 <= index < len(targets)):
        return False, "Нет такой цели."
    target = normalize_target(username)
    if not target:
        return False, "Пустой username."
    for pos, other in enumerate(targets):
        if pos != index and other["target"].lower() == target.lower():
            return False, "Такая цель уже есть в списке."
    targets[index]["target"] = target
    _sync_legacy_target(settings)
    return True, "Username цели изменён на %s." % display_target(target)


def _sync_legacy_target(settings):
    targets = settings.get("targets") or []
    settings["target"] = targets[0]["target"] if targets else ""


def is_target_set(settings):
    return any(t.get("enabled", True) for t in settings.get("targets") or [])


def display_target(value):
    target = normalize_target(value)
    if not target:
        return "NOT SET"
    if target.startswith("+") or target.isdigit():
        return target
    return "@" + target


# ------------------------------------------------------------- настройки
def _to_int(value, default, minimum=None, maximum=None):
    try:
        number = int(str(value).strip())
    except (TypeError, ValueError):
        return default
    if minimum is not None and number < minimum:
        return default
    if maximum is not None and number > maximum:
        return default
    return number


def _clean_chat_ids(raw):
    if isinstance(raw, str):
        raw = re.split(r"[,\s;]+", raw)
    if not isinstance(raw, list):
        return []
    result = []
    for item in raw:
        text = str(item).strip()
        if not text:
            continue
        if re.fullmatch(r"-?\d{1,20}", text) or re.fullmatch(r"@[A-Za-z0-9_]{4,32}", text):
            if text not in result:
                result.append(text)
    return result[:20]


def sanitize_settings(loaded):
    """
    Приводит словарь из файла (или импорта) к безопасному виду.
    Неизвестные ключи отбрасываются. Старое поле "target" (версия 2.0)
    автоматически превращается в первую цель с прежней базой history.db.
    """
    settings = dict(DEFAULT_SETTINGS)
    settings["targets"] = []
    notify_ids = []
    if not isinstance(loaded, dict):
        loaded = {}

    for key in DEFAULT_SETTINGS:
        if key in loaded:
            settings[key] = loaded[key]

    settings["api_id"] = _to_int(settings.get("api_id"), 0, 0)
    settings["api_hash"] = str(settings.get("api_hash") or "").strip()
    settings["phone"] = str(settings.get("phone") or "").strip()
    settings["bot_token"] = str(settings.get("bot_token") or "").strip()
    settings["update_url"] = str(settings.get("update_url") or "").strip()
    settings["interval_seconds"] = _to_int(
        settings.get("interval_seconds"), RECOMMENDED_INTERVAL
    )
    settings["web_port"] = _to_int(
        settings.get("web_port"), DEFAULT_WEB_PORT, 1024, 65535
    )
    for key in BOOL_KEYS:
        settings[key] = bool(settings.get(key))
    notify_ids = _clean_chat_ids(settings.get("notify_chat_ids"))
    settings["notify_chat_ids"] = notify_ids

    if "targets" in loaded:
        targets = _sanitize_targets(loaded.get("targets"))
    else:
        targets = []
    legacy = normalize_target(loaded.get("target"))
    if not targets and legacy:
        # Миграция с 2.0: прежняя база и папка аватарок остаются как были.
        targets = [_make_entry(legacy, db="history.db", avatars="")]
    settings["targets"] = targets
    _sync_legacy_target(settings)
    return settings


def load_settings():
    ensure_dirs()
    if not os.path.isfile(SETTINGS_PATH):
        return sanitize_settings({})
    try:
        with open(SETTINGS_PATH, "r", encoding="utf-8") as fh:
            loaded = json.load(fh)
    except (OSError, ValueError):
        return sanitize_settings({})
    return sanitize_settings(loaded)


def save_settings(settings):
    ensure_dirs()
    clean = sanitize_settings(settings)
    tmp_path = SETTINGS_PATH + ".tmp"
    with open(tmp_path, "w", encoding="utf-8") as fh:
        json.dump(clean, fh, ensure_ascii=False, indent=2)
    os.replace(tmp_path, SETTINGS_PATH)


def is_configured(settings):
    try:
        api_id = int(settings.get("api_id") or 0)
    except (TypeError, ValueError):
        api_id = 0
    return api_id > 0 and bool(str(settings.get("api_hash") or "").strip())


def validate_interval(value):
    try:
        interval = int(str(value).strip())
    except (TypeError, ValueError):
        return None
    if MIN_INTERVAL <= interval <= MAX_INTERVAL:
        return interval
    return None


def current_interval(settings):
    return validate_interval(settings.get("interval_seconds")) or RECOMMENDED_INTERVAL


def valid_bot_token(value):
    return bool(re.fullmatch(r"\d{5,15}:[A-Za-z0-9_\-]{30,60}", str(value or "").strip()))


# -------------------------------------------------------------- маскирование
def mask_secret(value, visible=4):
    """Маскирует секрет, оставляя только последние символы."""
    text = str(value or "")
    if not text:
        return "(не задано)"
    if len(text) <= visible:
        return "*" * len(text)
    return "*" * (len(text) - visible) + text[-visible:]


def mask_token(value):
    text = str(value or "")
    if not text:
        return "(не задано)"
    head, sep, tail = text.partition(":")
    if not sep:
        return mask_secret(text)
    return head + ":" + "*" * 6 + tail[-4:]


def mask_phone(value):
    """Маскирует номер телефона для показа в меню и панели."""
    text = str(value or "").strip()
    if not text:
        return "(не задано)"
    if len(text) <= 5:
        return "*" * len(text)
    return text[:2] + "*" * (len(text) - 4) + text[-2:]


def on_off(value):
    return "ON" if value else "OFF"
