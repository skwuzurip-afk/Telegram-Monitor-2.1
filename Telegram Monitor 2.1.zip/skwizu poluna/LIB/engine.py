# -*- coding: utf-8 -*-
"""
Telegram Monitor 2.1 - рабочий объект одной отслеживаемой цели.

У каждой цели своя база, своя папка аватарок и свои трекеры.
Все обращения к Telegram выполняются в главном потоке.
"""

import os
import time
from datetime import datetime

import logger as applog
from avatar_tracker import AvatarTracker
from config import current_interval, display_target
from database import (
    TARGET_CHANGED,
    open_database_safe,
    parse_ts,
    ts_now,
    ts_str,
)
from profile_tracker import ProfileTracker
from runtime import RUNTIME
from statistics import fmt_duration, format_console_event
from status_tracker import StatusTracker
from telegram_client import SessionInvalid, TargetNotFound
import ui

STATE_FIELDS = (
    "user_id",
    "first_name",
    "last_name",
    "username",
    "photo_id",
    "photo_file",
    "bio",
    "status",
    "status_label",
    "was_online",
    "online_since",
    "last_poll",
)


# ---------------------------------------------------------------- состояние
def load_state(db):
    return {field: (db.get_state(field) or "") for field in STATE_FIELDS}


def build_state(snap):
    was_online = snap.get("was_online")
    return {
        "user_id": "" if snap.get("user_id") is None else str(snap.get("user_id")),
        "first_name": snap.get("first_name") or "",
        "last_name": snap.get("last_name") or "",
        "username": snap.get("username") or "",
        "photo_id": snap.get("photo_id") or "",
        "photo_file": "",
        "bio": snap.get("bio") or "",
        "status": snap.get("status") or "unavailable",
        "status_label": snap.get("status_label") or "",
        "was_online": ts_str(was_online) if was_online else "",
        "online_since": "",
    }


def baseline_state(snap, settings, avatar_tracker):
    """Состояние при первом запуске или после смены цели. Без событий."""
    state = build_state(snap)
    if settings.get("track_status") and state.get("status") == "online":
        state["online_since"] = ts_str(datetime.now())
    if (
        settings.get("track_profile")
        and settings.get("avatar_history")
        and snap.get("photo_id")
    ):
        saved = avatar_tracker.archive_current(snap)
        state["photo_file"] = saved or ""
    state["last_poll"] = ts_now()
    return state


def process_snapshot(prev, snap, settings, db, status_tracker, profile_tracker, avatar_tracker):
    """
    Возвращает (events, new_state, mode), где mode:
      'baseline'       - первое сохранение состояния;
      'target_changed' - username указывает на другого пользователя;
      'update'         - обычная проверка.
    """
    now = datetime.now()
    current_user_id = str(snap.get("user_id") or "")
    previous_user_id = str(prev.get("user_id") or "")

    if previous_user_id and current_user_id and current_user_id != previous_user_id:
        # Старый открытый интервал закрываем, состояние полностью сбрасываем.
        start_dt = parse_ts(prev.get("online_since"))
        if start_dt is not None and settings.get("save_history"):
            duration = max(0, int((now - start_dt).total_seconds()))
            db.add_session(start_dt, now, duration)
        event = {
            "type": TARGET_CHANGED,
            "old_value": previous_user_id,
            "new_value": current_user_id,
        }
        db.reset_tracking_state()
        state = baseline_state(snap, settings, avatar_tracker)
        return [event], state, "target_changed"

    if not previous_user_id:
        state = baseline_state(snap, settings, avatar_tracker)
        return [], state, "baseline"

    events = []
    updates = {}

    status_events, status_updates = status_tracker.process(
        prev,
        snap,
        track=bool(settings.get("track_status")),
        now=now,
        save_sessions=bool(settings.get("save_history")),
    )
    events.extend(status_events)
    updates.update(status_updates)

    profile_events, profile_updates = profile_tracker.process(
        prev, snap, track=bool(settings.get("track_profile"))
    )
    events.extend(profile_events)
    updates.update(profile_updates)

    avatar_events, avatar_updates = avatar_tracker.process(
        prev,
        snap,
        track_profile=bool(settings.get("track_profile")),
        avatar_history=bool(settings.get("avatar_history")),
    )
    events.extend(avatar_events)
    updates.update(avatar_updates)

    state = build_state(snap)
    state.update(updates)
    state["last_poll"] = ts_now()
    return events, state, "update"


def _wait_seconds(reason, retry_after, interval):
    if reason == "flood":
        return max(1, int(retry_after or interval))
    return max(int(interval), int(retry_after or interval))


# ------------------------------------------------------------------ цель
class TargetWorker(object):
    def __init__(self, tinfo, settings, client):
        self.info = tinfo
        self.id = tinfo["id"]
        self.settings = settings
        self.client = client
        self.target = tinfo["target"]
        self.interval = current_interval(settings)
        self.multi = False
        self.avatars_dir = tinfo["avatars_dir"]
        os.makedirs(self.avatars_dir, exist_ok=True)

        self.db, self.warning = open_database_safe(
            tinfo["db_path"], log=lambda text: applog.warning(text)
        )
        self.status_tracker = StatusTracker(self.db)
        self.profile_tracker = ProfileTracker()
        self.avatar_tracker = AvatarTracker(
            self.db,
            self.avatars_dir,
            lambda snap, path: client.download_avatar(snap, path),
        )

        self.prev = load_state(self.db)
        self.known_id = self.prev.get("user_id") or None
        continuity_window = max(self.interval * 3, 180)
        if self.status_tracker.close_stale_session(
            self.prev,
            continuity_window,
            save_sessions=bool(settings.get("save_history")),
        ):
            applog.info("Stale online session closed after downtime (%s).", self.target)
            self.prev["online_since"] = ""
            self.prev["status"] = ""

        self.snap = None
        self.phase = "init"  # init | checking | ok | error
        self.detail = ""
        self.failures = 0
        self.next_due = 0.0
        self.last_check = None
        self.counters = {"events": 0, "avatars": 0}
        self.refresh_counters()

    # -------------------------------------------------------------- вывод
    def name(self):
        """Имя цели для сообщений: метка или @username."""
        label = (self.info.get("label") or "").strip()
        if label:
            return label
        username = self.prev.get("username")
        if username:
            return "@" + username
        return display_target(self.target)

    def _tag(self):
        return ("[%s] " % self.name()) if self.multi else ""

    def refresh_counters(self):
        try:
            self.counters = {
                "events": self.db.count_events(),
                "avatars": self.db.count_photos(),
            }
        except Exception:  # noqa: BLE001
            pass

    def view(self, now=None):
        """Данные цели для рамки CMD."""
        now = now or datetime.now()
        state = self.prev
        status = (state.get("status") or "").lower()
        title = self.name()
        full_name = " ".join(
            part for part in (state.get("first_name"), state.get("last_name")) if part
        ).strip()
        if (self.info.get("label") or "").strip() and state.get("username"):
            full_name = ("@" + state["username"] + "  " + full_name).strip()

        if status == "online":
            since = parse_ts(state.get("online_since"))
            elapsed = 0 if since is None else max(0, int((now - since).total_seconds()))
            kind, text = "online", "ONLINE · VISIBLE %s" % fmt_duration(elapsed)
        elif status == "offline":
            seen = parse_ts(state.get("was_online"))
            if seen is None:
                text = "OFFLINE"
            elif seen.date() == now.date():
                text = "OFFLINE · seen %s" % seen.strftime("%H:%M:%S")
            else:
                text = "OFFLINE · seen %s" % seen.strftime("%d.%m %H:%M")
            kind = "offline"
        elif status == "hidden":
            label = (state.get("status_label") or "").strip().upper()
            kind, text = "hidden", ("HIDDEN (%s)" % label if label else "HIDDEN")
        elif status == "unavailable":
            kind, text = "unavailable", "UNAVAILABLE"
        else:
            kind, text = "connecting", "WAITING FOR FIRST CHECK"

        if self.phase == "error":
            kind = "error"
            text = "%s · last: %s" % (self.detail or "ERROR", text) if status else (self.detail or "ERROR")
        elif self.phase == "init" and status:
            text += " (saved)"

        snap = self.snap or {}
        return {
            "title": title,
            "name": full_name,
            "kind": kind,
            "status": text,
            "user_id": state.get("user_id") or "",
            "phone": snap.get("phone") or "",
            "events": self.counters.get("events", 0),
            "avatars": self.counters.get("avatars", 0),
            "badges": snap.get("badges") or [],
            "bio": state.get("bio") or "",
        }

    # ----------------------------------------------------------- события
    def save_and_report(self, events, state):
        """Сохраняет цикл в базу, печатает события и отправляет уведомления."""
        for event in events:
            event["ts"] = ts_now()

        stored = events if self.settings.get("save_history") else []
        try:
            self.db.save_cycle(stored, state)
        except Exception as exc:  # noqa: BLE001
            applog.exception("Could not save cycle to database")
            ui.service("Could not save to database: %s" % exc, level="error")

        tag = ("%s: " % self.name()) if self.multi else ""
        for event in events:
            lines = format_console_event(event, event["ts"])
            if tag and lines:
                lines[0] = lines[0].replace("] ", "] " + tag, 1)
            if self.settings.get("print_events"):
                for line in lines:
                    ui.console(line)
            for line in lines:
                applog.info(line)

        notifier = RUNTIME.notifier
        if events and notifier is not None and notifier.enabled:
            notifier.notify_events(self.name(), events, self.avatars_dir)

    # ------------------------------------------------------------- опрос
    def poll(self):
        """
        Один опрос цели. Возвращает (результат, пауза):
          'ok' | 'notfound' | 'network' | 'flood'.
        SessionInvalid пробрасывается наверх.
        """
        interval = self.interval
        self.last_check = datetime.now()
        try:
            snap, retry_after, reason = self.client.get_snapshot(self.target, self.known_id)
        except TargetNotFound:
            self.failures += 1
            self.phase = "error"
            self.detail = "TARGET NOT FOUND"
            if self.failures == 1 or self.failures % 20 == 0:
                ui.service(
                    "Target %s not found. Check the username in CONFIG.bat." % self.name(),
                    level="warning",
                )
            wait = max(60, interval)
            self.next_due = time.time() + wait
            return "notfound", wait
        except SessionInvalid:
            raise

        if snap is None:
            self.failures += 1
            wait = _wait_seconds(reason, retry_after, interval)
            self.phase = "error"
            self.detail = "FLOODWAIT" if reason == "flood" else "NO CONNECTION"
            if reason == "flood":
                ui.service("Telegram FloodWait: pause %d sec." % wait)
            elif self.failures == 1 or self.failures % 20 == 0:
                ui.service("No connection to Telegram. Retrying...", level="warning")
            if self.failures % 5 == 0:
                self.client.reconnect()
            self.next_due = time.time() + wait
            return ("flood" if reason == "flood" else "network"), wait

        if self.failures:
            ui.service("%sConnection restored." % self._tag())
            self.failures = 0
        self.phase = "ok"
        self.detail = ""
        self.snap = snap
        self.known_id = snap.get("user_id") or self.known_id

        events, state, mode = process_snapshot(
            self.prev,
            snap,
            self.settings,
            self.db,
            self.status_tracker,
            self.profile_tracker,
            self.avatar_tracker,
        )
        self.save_and_report(events, state)
        self.prev = state
        self.refresh_counters()

        tag = self._tag()
        if mode == "baseline":
            ui.service("%sBaseline saved. Future changes will be written to the log." % tag)
            if state.get("status") == "hidden":
                ui.service(
                    "%sStatus is hidden by privacy settings. Only approximate "
                    "last-seen labels are available." % tag,
                    level="warning",
                )
            elif state.get("status") == "unavailable":
                ui.service(
                    "%sStatus is not available to your account (privacy settings)." % tag,
                    level="warning",
                )
            if state.get("photo_file"):
                ui.service("%sCurrent avatar archived: %s" % (tag, state["photo_file"]))
        elif mode == "target_changed":
            ui.service(
                "%sTarget user ID changed. Tracking state has been reset for the new user." % tag,
                level="warning",
            )

        self.next_due = time.time() + interval
        return "ok", 0

    def close(self):
        try:
            self.db.close()
        except Exception:  # noqa: BLE001
            pass
