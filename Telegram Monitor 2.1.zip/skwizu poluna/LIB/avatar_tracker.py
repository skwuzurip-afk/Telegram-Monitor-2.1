# -*- coding: utf-8 -*-
"""
Telegram Monitor 2.0 - архив аватарок.

Каждая замеченная версия фотографии скачивается в DATA/avatars/
под именем avatar_001.jpg, avatar_002.jpg и т. д.
Старые файлы не удаляются. В базе фиксируется photo_id и имя файла.
"""

import os
import re

from database import PHOTO


class AvatarTracker(object):
    def __init__(self, db, avatars_dir, downloader):
        """
        db         - Database;
        avatars_dir - каталог архива;
        downloader - функция(snap, path) -> путь к сохранённому файлу или None.
        """
        self.db = db
        self.avatars_dir = avatars_dir
        self.downloader = downloader

    # ------------------------------------------------------------------ файлы
    def _next_filename(self):
        os.makedirs(self.avatars_dir, exist_ok=True)
        highest = 0
        pattern = re.compile(r"^avatar_(\d+)\.jpg$", re.IGNORECASE)
        try:
            for name in os.listdir(self.avatars_dir):
                match = pattern.match(name)
                if match:
                    highest = max(highest, int(match.group(1)))
        except OSError:
            return "avatar_001.jpg"
        return "avatar_%03d.jpg" % (highest + 1)

    def save_photo(self, snap):
        """
        Скачивает текущую аватарку. Возвращает имя файла или None.
        Если эта версия уже сохранена, повторно не скачивает.
        """
        photo_id = str(snap.get("photo_id") or "").strip()
        if not photo_id:
            return None

        existing = self.db.get_photo_by_id(photo_id)
        if existing:
            filename = existing.get("filename") or ""
            if filename and os.path.isfile(os.path.join(self.avatars_dir, filename)):
                return filename

        filename = self._next_filename()
        path = os.path.join(self.avatars_dir, filename)
        saved = None
        try:
            saved = self.downloader(snap, path)
        except Exception:  # noqa: BLE001 - ошибка загрузки не должна ронять цикл
            saved = None

        actual_path = path
        if isinstance(saved, str) and saved:
            actual_path = saved
        if not (os.path.isfile(actual_path) and os.path.getsize(actual_path) > 0):
            # Неудачная загрузка: не оставляем пустые файлы и записи в базе.
            for candidate in (path, actual_path):
                try:
                    if os.path.isfile(candidate) and os.path.getsize(candidate) == 0:
                        os.remove(candidate)
                except OSError:
                    pass
            return None

        actual_name = os.path.basename(actual_path)
        self.db.add_photo(photo_id, actual_name)
        return actual_name

    # --------------------------------------------------------------- события
    def process(self, prev, snap, track_profile=True, avatar_history=True):
        """
        Возвращает (events, updates).

        Событие PHOTO создаётся при смене photo_id. Файлы скачиваются
        только если включены и отслеживание профиля, и архив аватарок.
        """
        old_id = str(prev.get("photo_id") or "").strip()
        new_id = str(snap.get("photo_id") or "").strip()
        old_file = str(prev.get("photo_file") or "").strip()

        updates = {"photo_id": new_id, "photo_file": old_file}
        events = []

        if old_id == new_id:
            updates["photo_file"] = old_file
            if (
                track_profile
                and avatar_history
                and new_id
                and not old_file
            ):
                # Аватарка была замечена раньше без архивации (например,
                # архив включили позже). Сохраняем текущую версию без события.
                saved = self.save_photo(snap)
                if saved:
                    updates["photo_file"] = saved
            return events, updates

        old_shown = old_file or ("photo_id:%s" % old_id if old_id else "")
        new_shown = ""
        note = None

        if new_id:
            if track_profile and avatar_history:
                saved = self.save_photo(snap)
                if saved:
                    new_shown = saved
                    updates["photo_file"] = saved
                else:
                    new_shown = "photo_id:%s" % new_id
                    updates["photo_file"] = ""
                    note = "file could not be saved"
            else:
                new_shown = "photo_id:%s" % new_id
                updates["photo_file"] = ""
        else:
            new_shown = ""
            updates["photo_file"] = ""
            note = "photo removed"

        if track_profile:
            events.append(
                {
                    "type": PHOTO,
                    "old_value": old_shown,
                    "new_value": new_shown,
                    "note": note,
                }
            )

        return events, updates

    # --------------------------------------------------------------- запуск
    def archive_current(self, snap):
        """Сохраняет текущую аватарку при первом запуске (без события)."""
        return self.save_photo(snap)
