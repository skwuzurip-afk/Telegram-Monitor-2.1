# -*- coding: utf-8 -*-
"""
Telegram Monitor 2.0 - просмотр истории, поиск и архив аватарок в CMD.
"""

import os
from datetime import datetime, time as dtime

from database import EVENT_TYPES
from statistics import format_history_event

PAGE_SIZE = 40


def _print_rows(rows):
    for row in rows:
        for line in format_history_event(row):
            print(line)


def view_history(db):
    offset = 0
    total = db.count_events()
    if total == 0:
        print("")
        print("История пуста: событий пока нет.")
        return

    print("")
    print("ИСТОРИЯ СОБЫТИЙ (всего записей: %d, новые сверху)" % total)
    print("")

    while True:
        rows = db.get_events(limit=PAGE_SIZE, offset=offset)
        if not rows:
            print("")
            print("Больше записей нет.")
            return
        _print_rows(rows)
        offset += len(rows)
        print("")
        if offset >= total:
            print("Конец истории.")
            return
        try:
            answer = input("[Enter] - следующие %d, [q] - назад: " % PAGE_SIZE)
        except EOFError:
            return
        if answer.strip().lower() in ("q", "й", "n", "назад"):
            return


def _parse_date(text, end_of_day=False):
    text = text.strip()
    if not text:
        return None
    for fmt in ("%d.%m.%Y", "%d.%m.%y"):
        try:
            parsed = datetime.strptime(text, fmt)
        except ValueError:
            continue
        if end_of_day:
            return datetime.combine(parsed.date(), dtime(23, 59, 59))
        return datetime.combine(parsed.date(), dtime(0, 0, 0))
    return None


def search_history(db):
    print("")
    print("ПОИСК ПО ИСТОРИИ")
    try:
        text = input("Текст (значение, тип; Enter - без фильтра): ").strip()
        print("Типы: %s" % ", ".join(EVENT_TYPES))
        etype = input("Тип события (Enter - любой): ").strip().upper()
        date_from_text = input("Дата с (ДД.ММ.ГГГГ, Enter - без ограничения): ").strip()
        date_to_text = input("Дата по (ДД.ММ.ГГГГ, Enter - без ограничения): ").strip()
    except EOFError:
        return

    if etype and etype not in EVENT_TYPES:
        print("Неизвестный тип события: %s" % etype)
        return

    date_from = _parse_date(date_from_text)
    date_to = _parse_date(date_to_text, end_of_day=True)
    if date_from_text and date_from is None:
        print("Некорректная дата 'с'. Формат: ДД.ММ.ГГГГ.")
        return
    if date_to_text and date_to is None:
        print("Некорректная дата 'по'. Формат: ДД.ММ.ГГГГ.")
        return

    rows = db.search_events(
        text=text or None,
        etype=etype or None,
        epoch_from=int(date_from.timestamp()) if date_from else None,
        epoch_to=int(date_to.timestamp()) if date_to else None,
        limit=300,
    )
    print("")
    if not rows:
        print("Ничего не найдено.")
        return

    print(
        "НАЙДЕНО ЗАПИСЕЙ: %d%s"
        % (len(rows), " (показаны первые 300)" if len(rows) >= 300 else "")
    )
    print("")
    _print_rows(rows)
    print("")


def view_photo_archive(db, avatars_dir):
    rows = db.get_photos(limit=500)
    print("")
    print("АРХИВ АВАТАРОК (DATA/avatars)")
    print("")
    if not rows:
        print("Сохранённых аватарок нет.")
        return
    for row in rows:
        filename = row.get("filename") or ""
        path = os.path.join(avatars_dir, filename)
        state = "OK" if os.path.isfile(path) else "MISSING"
        print(
            "[%s] %s    photo_id: %s    %s"
            % (
                row.get("ts") or "",
                filename or "(no file)",
                row.get("photo_id") or "-",
                state,
            )
        )
    print("")
    print("Всего записей: %d. Файлы лежат в DATA/avatars/." % len(rows))
