# -*- coding: utf-8 -*-
"""
Telegram Monitor 2.1 - проверка обновлений.

Программа ничего не скачивает и не устанавливает сама: она только сообщает,
что вышла новая версия, и даёт ссылку. Адрес источника задаётся в настройках
(CONFIG.bat -> 19), поддерживаются:

  1) страница репозитория GitHub:   https://github.com/ВЛАДЕЛЕЦ/РЕПО
     (берётся последний релиз, тег вида v2.2.0);
  2) прямой адрес API GitHub:       https://api.github.com/repos/ВЛАДЕЛЕЦ/РЕПО/releases/latest
  3) любой JSON-файл по HTTPS:      {"version": "2.2.0", "url": "...", "notes": "..."}
"""

import json
import re
import threading
import urllib.error
import urllib.request

import logger as applog
from config import APP_VERSION
from runtime import RUNTIME

CHECK_EVERY_SECONDS = 12 * 3600


def parse_version(text):
    """'v2.1.0-beta' -> (2, 1, 0). Нераспознанное -> ()."""
    numbers = re.findall(r"\d+", str(text or "").split("-")[0])
    return tuple(int(n) for n in numbers[:4])


def is_newer(latest, current):
    a, b = parse_version(latest), parse_version(current)
    if not a or not b:
        return False
    length = max(len(a), len(b))
    return a + (0,) * (length - len(a)) > b + (0,) * (length - len(b))


def normalize_source(url):
    """Адрес репозитория GitHub -> адрес API последнего релиза."""
    url = str(url or "").strip()
    match = re.match(r"^https?://(?:www\.)?github\.com/([^/\s]+)/([^/\s#?]+?)(?:\.git)?/?$", url)
    if match:
        return "https://api.github.com/repos/%s/%s/releases/latest" % match.groups()
    return url


def _fetch_json(url, timeout):
    request = urllib.request.Request(
        url,
        headers={
            "User-Agent": "TelegramMonitor/%s" % APP_VERSION,
            "Accept": "application/json",
        },
    )
    with urllib.request.urlopen(request, timeout=timeout) as response:
        raw = response.read(512 * 1024)
    return json.loads(raw.decode("utf-8", "replace"))


def check(url, current=APP_VERSION, timeout=10):
    """
    Возвращает словарь:
      status: 'disabled' | 'ok' | 'new' | 'error'
      latest, url, notes, message
    """
    source = normalize_source(url)
    if not source:
        return {"status": "disabled", "message": "Адрес обновлений не задан (CONFIG.bat -> 19)."}
    if not source.lower().startswith(("https://", "http://127.0.0.1", "http://localhost")):
        return {"status": "error", "message": "Разрешены только адреса https://."}
    try:
        data = _fetch_json(source, timeout)
    except urllib.error.HTTPError as exc:
        if exc.code == 404:
            return {"status": "error", "message": "Релизы не найдены (404). Проверьте адрес."}
        return {"status": "error", "message": "Сервер ответил кодом %d." % exc.code}
    except (urllib.error.URLError, OSError, ValueError) as exc:
        return {"status": "error", "message": "Нет связи: %s" % getattr(exc, "reason", exc)}

    if not isinstance(data, dict):
        return {"status": "error", "message": "Неожиданный ответ сервера."}
    latest = str(data.get("version") or data.get("tag_name") or data.get("latest") or "").strip()
    link = str(data.get("url") or data.get("html_url") or data.get("download_url") or "").strip()
    notes = str(data.get("notes") or data.get("changelog") or data.get("body") or "").strip()
    if not parse_version(latest):
        return {"status": "error", "message": "В ответе нет номера версии."}
    result = {
        "latest": latest.lstrip("vV"),
        "url": link if link.lower().startswith("https://") else "",
        "notes": notes[:600],
        "current": current,
    }
    if is_newer(latest, current):
        result["status"] = "new"
        result["message"] = "Доступна новая версия: %s (у вас %s)." % (result["latest"], current)
    else:
        result["status"] = "ok"
        result["message"] = "Установлена актуальная версия (%s)." % current
    return result


def start_background(settings, on_new=None):
    """Проверяет обновления при запуске и затем раз в 12 часов (отдельный поток)."""
    if not settings.get("update_check") or not str(settings.get("update_url") or "").strip():
        return None

    def worker():
        announced = None
        while not RUNTIME.stop.is_set():
            info = check(settings.get("update_url"))
            RUNTIME.update_info = info
            if info.get("status") == "new" and info.get("latest") != announced:
                announced = info.get("latest")
                applog.info("Update available: %s", info.get("latest"))
                if on_new is not None:
                    try:
                        on_new(info)
                    except Exception:  # noqa: BLE001
                        pass
            elif info.get("status") == "error":
                applog.warning("Update check failed: %s", info.get("message"))
            if RUNTIME.stop.wait(CHECK_EVERY_SECONDS):
                return

    thread = threading.Thread(target=worker, name="updater", daemon=True)
    thread.start()
    return thread
