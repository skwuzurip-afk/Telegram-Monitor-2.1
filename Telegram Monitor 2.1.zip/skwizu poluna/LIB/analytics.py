# -*- coding: utf-8 -*-
"""
Telegram Monitor 2.1 - данные и аналитика для веб-панели.

Читает базы целей только на чтение (отдельное соединение на каждый запрос),
поэтому безопасно работает параллельно с мониторингом.
"""

import os
import re
import sqlite3
import time
from datetime import datetime, timedelta

from config import APP_NAME, APP_VERSION, get_targets, target_title
from database import PHOTO, STATUS_ONLINE, parse_ts
from statistics import display_time, event_details, event_headline, fmt_duration

WINDOW_DAYS = 30
DAILY_DAYS = 14
SAFE_NAME_RE = re.compile(r"^[A-Za-z0-9_.\-]{1,120}$")


def _connect(path):
    conn = sqlite3.connect(path, timeout=10)
    conn.row_factory = sqlite3.Row
    try:
        conn.execute("PRAGMA query_only = ON;")
    except sqlite3.Error:
        pass
    return conn


def _day_start(moment):
    return moment.replace(hour=0, minute=0, second=0, microsecond=0)


def _overlap(start, end, lo, hi):
    return max(0, min(end, hi) - max(start, lo))


def _avatar_file(tinfo, name):
    """Имя файла аватарки, если он реально существует. Иначе None."""
    name = (name or "").strip()
    if not name or not SAFE_NAME_RE.match(name):
        return None
    if os.path.isfile(os.path.join(tinfo["avatars_dir"], name)):
        return name
    return None


def _intervals(conn, state, now_epoch):
    """Видимые онлайн-сессии за окно анализа (включая текущую открытую)."""
    since = now_epoch - WINDOW_DAYS * 86400
    items = []
    rows = conn.execute(
        "SELECT start_epoch, end_epoch FROM sessions "
        "WHERE end_epoch IS NULL OR end_epoch >= ? ORDER BY start_epoch ASC",
        (since,),
    ).fetchall()
    for row in rows:
        start = int(row["start_epoch"])
        end = int(row["end_epoch"]) if row["end_epoch"] is not None else now_epoch
        if end > start:
            items.append((start, min(end, now_epoch)))
    if (state.get("status") or "") == "online":
        started = parse_ts(state.get("online_since"))
        if started is not None:
            start = int(started.timestamp())
            if start < now_epoch:
                items.append((start, now_epoch))
    return items


def _hour_buckets(intervals):
    """Распределяет сессии по часам суток и по дням недели (в секундах)."""
    hours = [0] * 24
    heat = [[0] * 24 for _ in range(7)]
    for start, end in intervals:
        cursor = datetime.fromtimestamp(start)
        stop = datetime.fromtimestamp(end)
        guard = 0
        while cursor < stop and guard < 24 * 40:
            guard += 1
            next_hour = cursor.replace(minute=0, second=0, microsecond=0) + timedelta(hours=1)
            chunk = int((min(next_hour, stop) - cursor).total_seconds())
            if chunk > 0:
                hours[cursor.hour] += chunk
                heat[cursor.weekday()][cursor.hour] += chunk
            cursor = next_hour
    return hours, heat


def _median(values):
    if not values:
        return 0
    ordered = sorted(values)
    middle = len(ordered) // 2
    if len(ordered) % 2:
        return ordered[middle]
    return (ordered[middle - 1] + ordered[middle]) // 2


def empty_target(tinfo):
    return {
        "id": tinfo["id"],
        "target": tinfo["target"],
        "title": target_title(tinfo),
        "enabled": tinfo.get("enabled", True),
        "has_data": False,
        "profile": {},
        "kpi": {},
        "daily": [],
        "hourly": [0] * 24,
        "heat": [[0] * 24 for _ in range(7)],
        "sessions": {"count": 0, "avg": 0, "median": 0, "longest": 0},
        "types": {},
        "events": [],
        "gallery": {"changes": [], "archive": []},
    }


def build_target(tinfo, url_for, now=None):
    """Все данные одной цели для веб-панели."""
    now = now or datetime.now()
    now_epoch = int(now.timestamp())
    data = empty_target(tinfo)
    if not os.path.isfile(tinfo["db_path"]):
        return data

    conn = _connect(tinfo["db_path"])
    try:
        state = {row["key"]: row["value"] for row in conn.execute("SELECT key, value FROM app_state")}
        data["has_data"] = True

        first = state.get("first_name") or ""
        last = state.get("last_name") or ""
        avatar_name = _avatar_file(tinfo, state.get("photo_file"))
        data["profile"] = {
            "user_id": state.get("user_id") or "",
            "username": state.get("username") or "",
            "name": (first + " " + last).strip(),
            "bio": state.get("bio") or "",
            "status": state.get("status") or "",
            "status_label": state.get("status_label") or "",
            "was_online": display_time(state.get("was_online")) if state.get("was_online") else "",
            "online_since": state.get("online_since") or "",
            "last_poll": display_time(state.get("last_poll")) if state.get("last_poll") else "",
            "avatar": url_for(tinfo, avatar_name) if avatar_name else "",
        }

        # --- сессии и распределение активности
        intervals = _intervals(conn, state, now_epoch)
        today0 = int(_day_start(now).timestamp())
        week0 = now_epoch - 7 * 86400
        online_today = sum(_overlap(s, e, today0, now_epoch) for s, e in intervals)
        online_week = sum(_overlap(s, e, week0, now_epoch) for s, e in intervals)

        online_events = [
            int(row["epoch"])
            for row in conn.execute(
                "SELECT epoch FROM events WHERE type = ? AND epoch >= ?",
                (STATUS_ONLINE, now_epoch - DAILY_DAYS * 86400 - 86400),
            )
        ]
        daily = []
        for back in range(DAILY_DAYS - 1, -1, -1):
            day = _day_start(now) - timedelta(days=back)
            lo = int(day.timestamp())
            hi = int((day + timedelta(days=1)).timestamp())
            seconds = sum(_overlap(s, e, lo, hi) for s, e in intervals)
            starts = sum(1 for epoch in online_events if lo <= epoch < hi)
            daily.append({"label": day.strftime("%d.%m"), "seconds": seconds, "starts": starts})
        data["daily"] = daily

        hours, heat = _hour_buckets(intervals)
        data["hourly"] = hours
        data["heat"] = heat

        lengths = [e - s for s, e in intervals if e - s > 0]
        data["sessions"] = {
            "count": len(lengths),
            "avg": int(sum(lengths) / len(lengths)) if lengths else 0,
            "median": _median(lengths),
            "longest": max(lengths) if lengths else 0,
        }

        # --- события
        types = {
            row["type"]: int(row["n"])
            for row in conn.execute("SELECT type, COUNT(*) AS n FROM events GROUP BY type")
        }
        data["types"] = types
        total_events = sum(types.values())
        profile_changes = sum(
            types.get(key, 0) for key in ("FIRST_NAME", "LAST_NAME", "USERNAME", "BIO")
        )

        events = []
        for row in conn.execute(
            "SELECT ts, type, old_value, new_value, duration FROM events "
            "ORDER BY epoch DESC, id DESC LIMIT 300"
        ):
            event = dict(row)
            event["old_value"] = event.get("old_value")
            item = {
                "ts": display_time(event["ts"]),
                "type": event["type"],
                "title": event_headline(
                    {
                        "type": event["type"],
                        "old_value": event["old_value"],
                        "new_value": event["new_value"],
                    }
                ),
                "details": [
                    line.strip()
                    for line in event_details(
                        {
                            "type": event["type"],
                            "old_value": event["old_value"],
                            "new_value": event["new_value"],
                            "duration": event["duration"],
                        }
                    )
                ],
            }
            events.append(item)
        data["events"] = events

        # --- галерея аватарок: что было и на что изменено
        changes = []
        for row in conn.execute(
            "SELECT ts, old_value, new_value FROM events WHERE type = ? "
            "ORDER BY epoch DESC, id DESC LIMIT 200",
            (PHOTO,),
        ):
            old_name = _avatar_file(tinfo, row["old_value"])
            new_name = _avatar_file(tinfo, row["new_value"])
            changes.append(
                {
                    "ts": display_time(row["ts"]),
                    "old": url_for(tinfo, old_name) if old_name else "",
                    "new": url_for(tinfo, new_name) if new_name else "",
                    "old_label": (row["old_value"] or "").strip(),
                    "new_label": (row["new_value"] or "").strip(),
                    "removed": not (row["new_value"] or "").strip(),
                }
            )
        archive = []
        for row in conn.execute(
            "SELECT ts, photo_id, filename FROM photos ORDER BY epoch DESC, id DESC LIMIT 300"
        ):
            name = _avatar_file(tinfo, row["filename"])
            archive.append(
                {
                    "ts": display_time(row["ts"]),
                    "photo_id": row["photo_id"] or "",
                    "file": row["filename"] or "",
                    "url": url_for(tinfo, name) if name else "",
                }
            )
        data["gallery"] = {"changes": changes, "archive": archive}

        peak = max(range(24), key=lambda h: hours[h]) if any(hours) else None
        data["kpi"] = {
            "online_today": online_today,
            "online_week": online_week,
            "sessions": len(lengths),
            "events": total_events,
            "photo_changes": types.get(PHOTO, 0),
            "profile_changes": profile_changes,
            "peak_hour": peak,
            "online_today_text": fmt_duration(online_today),
            "online_week_text": fmt_duration(online_week),
        }
    finally:
        conn.close()
    return data


def build_payload(settings, url_for, runtime=None, now=None):
    now = now or datetime.now()
    app = {
        "name": APP_NAME,
        "version": APP_VERSION,
        "generated": now.strftime("%d.%m.%Y %H:%M:%S"),
        "uptime": 0,
        "paused": False,
    }
    if runtime is not None:
        app["uptime"] = int(time.time() - runtime.started)
        app["paused"] = bool(runtime.paused)
        info = runtime.update_info or {}
        if info.get("status") == "new":
            app["update"] = {"version": info.get("latest"), "url": info.get("url")}
    targets = [build_target(t, url_for, now) for t in get_targets(settings)]
    return {"app": app, "targets": targets}
