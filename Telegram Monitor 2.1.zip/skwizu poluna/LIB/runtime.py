# -*- coding: utf-8 -*-
"""
Telegram Monitor 2.1 - общее состояние работающего процесса.

Им пользуются главный цикл, трей, веб-панель и проверка обновлений.
Все обращения к Telegram остаются в главном потоке.
"""

import threading
import time


class _Runtime(object):
    def __init__(self):
        self.stop = threading.Event()
        self.paused = False
        self.started = time.time()
        self.background = False  # запуск без окна (pythonw)
        self.console_hidden = False
        self.tray_active = False
        self.web_url = ""
        self.update_info = None  # результат updater.check()
        self.notifier = None
        # краткое состояние для трея
        self.summary = "Telegram Monitor"
        self.color = "gray"  # green | gray | red | yellow


RUNTIME = _Runtime()
