# -*- coding: utf-8 -*-
"""
Telegram Monitor 2.1 - уведомления через вашего Telegram-бота.

Бот создаётся у @BotFather, токен вводится в CONFIG.bat. Получатели -
любые chat_id (ваш личный чат, друг, группа): у каждого должен быть
хотя бы раз нажат /start у бота. Отправка идёт в отдельном потоке,
поэтому сеть не тормозит мониторинг. Используется только стандартная
библиотека Python (Bot API по HTTPS).
"""

import json
import mimetypes
import os
import queue
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import uuid

import logger as applog
from database import (
    BIO,
    FIRST_NAME,
    LAST_NAME,
    LAST_SEEN,
    PHOTO,
    STATUS_HIDDEN,
    STATUS_OFFLINE,
    STATUS_ONLINE,
    STATUS_UNAVAILABLE,
    TARGET_CHANGED,
    USERNAME,
)
from statistics import display_time, fmt_duration

API_BASE = "https://api.telegram.org"

STATUS_TYPES = (STATUS_ONLINE, STATUS_OFFLINE, STATUS_HIDDEN, STATUS_UNAVAILABLE, LAST_SEEN)
PROFILE_TYPES = (FIRST_NAME, LAST_NAME, USERNAME, BIO)


class NotifyError(Exception):
    pass


# ------------------------------------------------------------------ HTTP
def _multipart(fields, files):
    boundary = "----tm" + uuid.uuid4().hex
    chunks = []
    for key, value in (fields or {}).items():
        chunks.append(
            ("--%s\r\nContent-Disposition: form-data; name=\"%s\"\r\n\r\n%s\r\n"
             % (boundary, key, value)).encode("utf-8")
        )
    for key, filename, data, ctype in files or []:
        chunks.append(
            ("--%s\r\nContent-Disposition: form-data; name=\"%s\"; filename=\"%s\"\r\n"
             "Content-Type: %s\r\n\r\n" % (boundary, key, filename, ctype)).encode("utf-8")
        )
        chunks.append(data)
        chunks.append(b"\r\n")
    chunks.append(("--%s--\r\n" % boundary).encode("utf-8"))
    return b"".join(chunks), "multipart/form-data; boundary=%s" % boundary


def api_call(token, method, fields=None, files=None, base=None, timeout=25):
    """Вызов Bot API. Возвращает разобранный JSON-ответ (dict)."""
    url = "%s/bot%s/%s" % (base or API_BASE, token, method)
    fields = dict(fields or {})
    if files:
        body, ctype = _multipart(fields, files)
    else:
        body = urllib.parse.urlencode(fields).encode("utf-8")
        ctype = "application/x-www-form-urlencoded"
    request = urllib.request.Request(url, data=body, headers={"Content-Type": ctype})
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            return json.loads(response.read().decode("utf-8", "replace"))
    except urllib.error.HTTPError as exc:
        try:
            return json.loads(exc.read().decode("utf-8", "replace"))
        except Exception:  # noqa: BLE001
            return {"ok": False, "error_code": exc.code, "description": str(exc)}
    except (urllib.error.URLError, OSError, ValueError) as exc:
        raise NotifyError(str(getattr(exc, "reason", exc)))


# -------------------------------------------------------------- тексты
def who(title):
    return title or "цель"


def describe_event(title, event):
    """Текст уведомления для события. None - уведомлять не нужно."""
    etype = event.get("type")
    old = event.get("old_value") or ""
    new = event.get("new_value") or ""
    name = who(title)

    if etype == STATUS_ONLINE:
        return "🟢 %s в сети" % name
    if etype == STATUS_OFFLINE:
        text = "⚪️ %s вышел(а) из сети" % name
        if new:
            text += "\nПоследний визит: %s" % display_time(new)
        if event.get("duration") is not None:
            text += "\nСессия: %s" % fmt_duration(event["duration"])
        return text
    if etype == STATUS_HIDDEN:
        text = "🕶 %s: статус скрыт" % name
        if new:
            text += " (%s)" % new.lower()
        return text
    if etype == STATUS_UNAVAILABLE:
        return "🚫 %s: статус недоступен" % name
    if etype == LAST_SEEN:
        return "👁 %s: обновился визит\n%s → %s" % (
            name, display_time(old) if old else "?", display_time(new))
    labels = {
        FIRST_NAME: "имя",
        LAST_NAME: "фамилия",
        USERNAME: "username",
        BIO: "описание профиля",
    }
    if etype in labels:
        if etype == USERNAME:
            old = ("@" + old.lstrip("@")) if old else "(пусто)"
            new = ("@" + new.lstrip("@")) if new else "(пусто)"
        return "✏️ %s: изменено %s\n%s → %s" % (name, labels[etype], old or "(пусто)", new or "(пусто)")
    if etype == PHOTO:
        if not new:
            return "🗑 %s удалил(а) аватарку" % name
        return "🖼 %s сменил(а) аватарку" % name
    if etype == TARGET_CHANGED:
        return "⚠️ %s: username теперь указывает на другого пользователя (ID %s → %s)" % (
            name, old, new)
    return None


def _category(event):
    etype = event.get("type")
    if etype in STATUS_TYPES:
        return "status"
    if etype in PROFILE_TYPES:
        return "profile"
    if etype == PHOTO:
        return "photo"
    return "always"


# ----------------------------------------------------------- отправщик
class Notifier(object):
    def __init__(self, settings, base=None):
        self.base = base
        self.queue = queue.Queue(maxsize=300)
        self.thread = None
        self.lock = threading.Lock()
        self.stats = {"sent": 0, "failed": 0, "last_error": ""}
        self.configure(settings)

    def configure(self, settings):
        self.token = str(settings.get("bot_token") or "").strip()
        self.chat_ids = list(settings.get("notify_chat_ids") or [])
        self.flags = {
            "status": bool(settings.get("notify_status")),
            "profile": bool(settings.get("notify_profile")),
            "photo": bool(settings.get("notify_photo")),
            "send_photo": bool(settings.get("notify_send_photo")),
        }
        self.on = bool(settings.get("notify_enabled")) and bool(self.token) and bool(self.chat_ids)

    @property
    def enabled(self):
        return self.on

    def badge(self):
        """Краткая отметка для рамки CMD: 'ON(2)', 'ERR' и т. п. None - выключено."""
        if not self.on:
            return None
        if self.stats["failed"] and not self.stats["sent"]:
            return "ERR"
        return "ON(%d)" % len(self.chat_ids)

    # ---------------------------------------------------------- поток
    def start(self):
        if not self.on or self.thread is not None:
            return
        self.thread = threading.Thread(target=self._loop, name="notifier", daemon=True)
        self.thread.start()

    def stop(self, wait=6.0):
        if self.thread is None:
            return
        deadline = time.time() + wait
        while not self.queue.empty() and time.time() < deadline:
            time.sleep(0.1)
        try:
            self.queue.put_nowait(None)
        except queue.Full:
            pass
        self.thread.join(timeout=2)
        self.thread = None

    def _loop(self):
        while True:
            job = self.queue.get()
            if job is None:
                return
            try:
                self._deliver(job)
            except Exception as exc:  # noqa: BLE001 - поток не должен падать
                self._fail("unexpected: %s" % exc)
            time.sleep(0.05)

    def _fail(self, message):
        with self.lock:
            self.stats["failed"] += 1
            self.stats["last_error"] = str(message)[:200]
        applog.warning("Bot notification failed: %s", message)

    def _deliver(self, job):
        method, fields, files = job
        for attempt in range(1, 4):
            try:
                reply = api_call(self.token, method, fields, files, base=self.base)
            except NotifyError as exc:
                if attempt == 3:
                    self._fail(exc)
                    return
                time.sleep(2 * attempt)
                continue
            if reply.get("ok"):
                with self.lock:
                    self.stats["sent"] += 1
                return
            code = reply.get("error_code")
            if code == 429 and attempt < 3:
                delay = int((reply.get("parameters") or {}).get("retry_after") or 3)
                time.sleep(min(delay + 1, 30))
                continue
            self._fail("%s %s" % (code, reply.get("description")))
            return

    def _enqueue(self, method, fields, files=None):
        try:
            self.queue.put_nowait((method, fields, files))
        except queue.Full:
            self._fail("queue is full")

    # --------------------------------------------------------- отправка
    def send_text(self, text):
        if not self.on:
            return
        for chat in self.chat_ids:
            self._enqueue("sendMessage", {"chat_id": chat, "text": text, "disable_web_page_preview": "true"})

    def _read_file(self, path):
        try:
            with open(path, "rb") as fh:
                return fh.read()
        except OSError:
            return None

    def send_photos(self, text, old_path=None, new_path=None):
        """Одна или две аватарки (было -> стало) с подписью."""
        files_data = []
        for key, path in (("old", old_path), ("new", new_path)):
            if path and os.path.isfile(path):
                data = self._read_file(path)
                if data:
                    ctype = mimetypes.guess_type(path)[0] or "image/jpeg"
                    files_data.append((key, os.path.basename(path), data, ctype))
        if not files_data:
            self.send_text(text)
            return
        for chat in self.chat_ids:
            if len(files_data) == 2:
                media = [
                    {"type": "photo", "media": "attach://old", "caption": text + "\n(слева старая, справа новая)"},
                    {"type": "photo", "media": "attach://new"},
                ]
                self._enqueue(
                    "sendMediaGroup",
                    {"chat_id": chat, "media": json.dumps(media, ensure_ascii=False)},
                    files_data,
                )
            else:
                key, filename, data, ctype = files_data[0]
                self._enqueue(
                    "sendPhoto",
                    {"chat_id": chat, "caption": text},
                    [("photo", filename, data, ctype)],
                )

    def notify_events(self, title, events, avatars_dir=None):
        """Отправляет уведомления о событиях цели с учётом фильтров."""
        if not self.on:
            return
        for event in events:
            category = _category(event)
            if category in self.flags and not self.flags[category]:
                continue
            text = describe_event(title, event)
            if not text:
                continue
            if event.get("type") == PHOTO and self.flags.get("send_photo") and avatars_dir:
                old_name = (event.get("old_value") or "").strip()
                new_name = (event.get("new_value") or "").strip()
                old_path = os.path.join(avatars_dir, old_name) if old_name else None
                new_path = os.path.join(avatars_dir, new_name) if new_name else None
                if new_name and not new_name.startswith("photo_id:"):
                    if old_name.startswith("photo_id:"):
                        old_path = None
                    self.send_photos(text, old_path, new_path)
                    continue
            self.send_text(text)

    def notify_system(self, text):
        self.send_text("ℹ️ Telegram Monitor: %s" % text)


# --------------------------------------------------- проверки (CONFIG)
def check_token(token, base=None):
    """Возвращает (успех, @имя_бота или текст ошибки)."""
    try:
        reply = api_call(token, "getMe", base=base, timeout=15)
    except NotifyError as exc:
        return False, "нет связи с api.telegram.org: %s" % exc
    if reply.get("ok"):
        return True, "@" + str((reply.get("result") or {}).get("username") or "?")
    return False, str(reply.get("description") or "токен не принят")


def send_test(token, chat_ids, base=None):
    """Тестовое сообщение каждому получателю. Возвращает список (chat_id, успех, текст)."""
    results = []
    for chat in chat_ids:
        try:
            reply = api_call(
                token,
                "sendMessage",
                {"chat_id": chat, "text": "✅ Telegram Monitor: тестовое уведомление. Всё работает."},
                base=base,
                timeout=15,
            )
        except NotifyError as exc:
            results.append((chat, False, str(exc)))
            continue
        if reply.get("ok"):
            results.append((chat, True, "доставлено"))
        else:
            results.append((chat, False, str(reply.get("description") or "ошибка")))
    return results


def discover_chats(token, base=None):
    """
    Ищет чаты, которые писали боту (например, нажали /start).
    Возвращает список (chat_id, описание).
    """
    try:
        reply = api_call(token, "getUpdates", {"timeout": 0, "limit": 100}, base=base, timeout=15)
    except NotifyError:
        return []
    found = {}
    for update in reply.get("result") or []:
        for key in ("message", "edited_message", "channel_post", "my_chat_member"):
            chat = (update.get(key) or {}).get("chat")
            if not chat or chat.get("id") is None:
                continue
            name = chat.get("username") and "@" + chat["username"]
            name = name or " ".join(
                part for part in (chat.get("first_name"), chat.get("last_name")) if part
            ) or chat.get("title") or "?"
            found[str(chat["id"])] = "%s (%s)" % (name, chat.get("type", "chat"))
    return sorted(found.items())
