# -*- coding: utf-8 -*-
"""
Telegram Monitor 2.0 - форматирование событий, статистика и экспорт.

События в консоли и журнале имеют английские названия, например:
  STATUS: ONLINE
  USERNAME CHANGED
      OLD: @old_name
      NEW: @new_name
"""

import csv
import os
import time
from collections import Counter
from datetime import datetime, timedelta

from config import EXPORTS_DIR, ensure_dirs
from database import (
    BIO,
    FIRST_NAME,
    LAST_NAME,
    LAST_SEEN,
    PHOTO,
    STATUS_HIDDEN,
    STATUS_OFFLINE,
    STATUS_ONLINE,
    STATUS_UNAVAILABLE,
    TARGET_CHANGED,
    USERNAME,
    parse_ts,
)


def fmt_duration(seconds):
    """Секунды -> '45s', '12m 03s', '1h 02m 05s'."""
    try:
        total = max(0, int(seconds))
    except (TypeError, ValueError):
        total = 0
    hours, remainder = divmod(total, 3600)
    minutes, secs = divmod(remainder, 60)
    if hours:
        return "%dh %02dm %02ds" % (hours, minutes, secs)
    if minutes:
        return "%dm %02ds" % (minutes, secs)
    return "%ds" % secs


def display_time(ts_text):
    """'ГГГГ-ММ-ДД ЧЧ:ММ:СС' -> 'ДД.ММ.ГГГГ ЧЧ:ММ:СС'."""
    parsed = parse_ts(ts_text)
    if parsed is None:
        return str(ts_text or "")
    return parsed.strftime("%d.%m.%Y %H:%M:%S")


def display_clock(ts_text):
    parsed = parse_ts(ts_text)
    if parsed is None:
        return str(ts_text or "")
    return parsed.strftime("%H:%M:%S")


def display_day_time(ts_text):
    parsed = parse_ts(ts_text)
    if parsed is None:
        return str(ts_text or "")
    return parsed.strftime("%d.%m.%Y %H:%M:%S")


def _value(value, empty="(empty)"):
    text = "" if value is None else str(value)
    return text if text else empty


def _username(value):
    text = "" if value is None else str(value).strip()
    if not text:
        return "(empty)"
    if text.startswith("@") or text.startswith("photo_id:") or text.startswith("("):
        return text
    return "@" + text


def _photo_value(value):
    text = "" if value is None else str(value).strip()
    return text if text else "(none)"


def event_headline(event):
    """Первая строка события без отметки времени."""
    etype = event.get("type") or ""
    if etype == STATUS_ONLINE:
        return "STATUS: ONLINE"
    if etype == STATUS_OFFLINE:
        return "STATUS: OFFLINE"
    if etype == STATUS_HIDDEN:
        return "STATUS: HIDDEN"
    if etype == STATUS_UNAVAILABLE:
        return "STATUS: UNAVAILABLE"
    if etype == LAST_SEEN:
        return "LAST SEEN CHANGED"
    if etype == FIRST_NAME:
        return "FIRST NAME CHANGED"
    if etype == LAST_NAME:
        return "LAST NAME CHANGED"
    if etype == USERNAME:
        return "USERNAME CHANGED"
    if etype == BIO:
        return "BIO CHANGED"
    if etype == PHOTO:
        if not (event.get("new_value") or "").strip():
            return "PROFILE PHOTO REMOVED"
        return "PROFILE PHOTO CHANGED"
    if etype == TARGET_CHANGED:
        return "TARGET CHANGED"
    return etype


def event_details(event):
    """Строки деталей события (OLD/NEW и служебные примечания)."""
    etype = event.get("type") or ""
    old_value = event.get("old_value")
    new_value = event.get("new_value")
    duration = event.get("duration")
    note = event.get("note")
    details = []

    if etype == STATUS_OFFLINE:
        if new_value:
            details.append("    LAST SEEN: %s" % display_time(new_value))
        if duration is not None:
            details.append("    VISIBLE SESSION: %s" % fmt_duration(duration))
    elif etype == STATUS_HIDDEN:
        label = _value(new_value, "")
        old_label = _value(old_value, "")
        if label and old_label and old_label != label:
            details.append("    LAST SEEN: %s (was: %s)" % (label, old_label))
        elif label:
            details.append("    LAST SEEN: %s (approximate)" % label)
        if duration is not None:
            details.append("    VISIBLE SESSION ENDED: ~%s" % fmt_duration(duration))
    elif etype == STATUS_UNAVAILABLE:
        if duration is not None:
            details.append("    VISIBLE SESSION ENDED: ~%s" % fmt_duration(duration))
    elif etype == LAST_SEEN:
        details.append("    OLD: %s" % (display_time(old_value) if old_value else "(unknown)"))
        details.append("    NEW: %s" % display_time(new_value))
    elif etype in (FIRST_NAME, LAST_NAME, BIO):
        details.append("    OLD: %s" % _value(old_value))
        details.append("    NEW: %s" % _value(new_value))
    elif etype == USERNAME:
        details.append("    OLD: %s" % _username(old_value))
        details.append("    NEW: %s" % _username(new_value))
    elif etype == PHOTO:
        details.append("    OLD: %s" % _photo_value(old_value))
        details.append("    NEW: %s" % _photo_value(new_value))
    elif etype == TARGET_CHANGED:
        details.append("    OLD ID: %s" % _value(old_value))
        details.append("    NEW ID: %s" % _value(new_value))

    if note:
        details.append("    NOTE: %s" % note)
    return details


def event_lines(event):
    """Список строк события без отметки времени."""
    return [event_headline(event)] + event_details(event)


def format_console_event(event, ts_text):
    """Строки для CMD: время только у первой строки."""
    lines = event_lines(event)
    if not lines:
        return []
    result = ["[%s] %s" % (display_clock(ts_text), lines[0])]
    result.extend(lines[1:])
    return result


def format_history_event(row):
    """Строки для просмотра истории: полная дата у первой строки."""
    lines = event_lines(row)
    if not lines:
        return []
    result = ["[%s] %s" % (display_time(row.get("ts")), lines[0])]
    result.extend(lines[1:])
    return result


def _day_start(moment):
    return moment.replace(hour=0, minute=0, second=0, microsecond=0)


def _summary(db, start, end, title):
    epoch_from = int(start.timestamp())
    epoch_to = int(end.timestamp())

    events = db.events_between(epoch_from, epoch_to)
    counts = Counter(event["type"] for event in events)

    sessions = db.sessions_between(epoch_from, epoch_to)
    total_seconds = 0
    for session in sessions:
        start_epoch = int(session.get("start_epoch") or 0)
        end_epoch = session.get("end_epoch")
        end_epoch = int(end_epoch) if end_epoch is not None else epoch_to
        overlap = min(end_epoch, epoch_to) - max(start_epoch, epoch_from)
        if overlap > 0:
            total_seconds += overlap

    lines = [title]
    if not events and not sessions:
        lines.append("  No events in this period.")
        return lines

    lines.append(
        "  ONLINE: %d    OFFLINE: %d    LAST SEEN updates: %d"
        % (counts.get(STATUS_ONLINE, 0), counts.get(STATUS_OFFLINE, 0), counts.get(LAST_SEEN, 0))
    )
    lines.append(
        "  Hidden/unavailable status events: %d"
        % (counts.get(STATUS_HIDDEN, 0) + counts.get(STATUS_UNAVAILABLE, 0))
    )
    lines.append("  Total visible online time: %s" % fmt_duration(total_seconds))
    lines.append(
        "  Profile changes: first name %d, last name %d, username %d, bio %d, photo %d"
        % (
            counts.get(FIRST_NAME, 0),
            counts.get(LAST_NAME, 0),
            counts.get(USERNAME, 0),
            counts.get(BIO, 0),
            counts.get(PHOTO, 0),
        )
    )
    last_seen = None
    for event in reversed(events):
        if event.get("type") in (STATUS_OFFLINE, LAST_SEEN) and event.get("new_value"):
            last_seen = event["new_value"]
            break
    if last_seen:
        lines.append("  Last known visit: %s" % display_time(last_seen))
    return lines


def stats_today(db):
    now = datetime.now()
    start = _day_start(now)
    return _summary(db, start, now, "Statistics for today (%s):" % start.strftime("%d.%m.%Y"))


def stats_week(db):
    now = datetime.now()
    start = _day_start(now) - timedelta(days=6)
    return _summary(
        db,
        start,
        now,
        "Statistics for 7 days (%s - %s):"
        % (start.strftime("%d.%m.%Y"), now.strftime("%d.%m.%Y")),
    )


def show_stats(db):
    print("")
    for line in stats_today(db):
        print(line)
    print("")
    for line in stats_week(db):
        print(line)
    print("")


def _export_path(extension):
    ensure_dirs()
    return os.path.join(
        EXPORTS_DIR,
        "history_%s.%s" % (datetime.now().strftime("%Y%m%d_%H%M%S"), extension),
    )


def export_txt(db, target=None):
    path = _export_path("txt")
    now = datetime.now()
    events = db.events_between(0, int(time.time()) + 86400)
    lines = [
        "TELEGRAM MONITOR - HISTORY EXPORT",
        "Export date: %s" % now.strftime("%d.%m.%Y %H:%M:%S"),
    ]
    if target:
        lines.append("Target: %s" % target)
    lines.append("Events: %d" % len(events))
    lines.append("")
    lines.extend(stats_today(db))
    lines.append("")
    lines.extend(stats_week(db))
    lines.append("")
    lines.append("=" * 60)
    lines.append("EVENT LOG")
    lines.append("=" * 60)
    if not events:
        lines.append("No events.")
    for event in events:
        lines.extend(format_history_event(event))
    lines.append("")
    lines.append("End of log.")
    with open(path, "w", encoding="utf-8-sig", newline="\r\n") as fh:
        fh.write("\n".join(lines))
    return path


def export_csv(db, target=None):
    path = _export_path("csv")
    now = datetime.now()
    events = db.events_between(0, int(time.time()) + 86400)
    with open(path, "w", encoding="utf-8-sig", newline="") as fh:
        writer = csv.writer(fh, delimiter=";")
        writer.writerow(["EXPORT_DATE", now.strftime("%d.%m.%Y %H:%M:%S")])
        if target:
            writer.writerow(["TARGET", target])
        writer.writerow([])
        writer.writerow(
            ["DATE", "TIME", "EVENT", "OLD_VALUE", "NEW_VALUE", "DURATION_SEC", "DETAILS"]
        )
        for event in events:
            parsed = parse_ts(event.get("ts"))
            writer.writerow(
                [
                    parsed.strftime("%d.%m.%Y") if parsed else "",
                    parsed.strftime("%H:%M:%S") if parsed else "",
                    event.get("type") or "",
                    event.get("old_value") or "",
                    event.get("new_value") or "",
                    "" if event.get("duration") is None else int(event["duration"]),
                    " | ".join(line.strip() for line in event_details(event)),
                ]
            )
    return path
